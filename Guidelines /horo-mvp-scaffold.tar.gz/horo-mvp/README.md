# HORO Egypt — MVP Storefront

**Wear What You Mean** — Original wearable illustration for urban Egypt.

## Tech Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Framework | Next.js 15 (App Router) | SSR + RSC + ISR |
| Deployment | Vercel | Edge CDN, image optimization |
| Styling | Tailwind CSS v4 | Glassmorphism design system |
| UI Animation | Motion (Framer Motion) | Component-level hover, mount, layout |
| Scroll Animation | GSAP + ScrollTrigger | Homepage parallax, scroll storytelling |
| UI Components | shadcn/ui + Radix | Accessible, unstyled primitives |
| CMS | Sanity | Bilingual content, artist profiles |
| Commerce | Medusa.js v2 | Products, cart, checkout, orders |
| Images | Cloudinary + Next/Image | Responsive, optimized art delivery |
| i18n | next-intl | English + Arabic with RTL |
| Analytics | PostHog + Meta Pixel | Funnel tracking, ad attribution |
| Payments | Paymob | Cards, mobile wallets, COD |
| Shipping | Bosta | COD collection, try-before-you-buy |
| Messaging | Wati (WhatsApp API) | Order updates, abandoned cart |

## Project Structure

```
src/
├── app/
│   └── [locale]/           # i18n routing (en/ar)
│       ├── (shop)/          # Store pages
│       │   ├── page.tsx     # Homepage (scroll storytelling)
│       │   └── products/
│       │       └── [slug]/
│       │           └── page.tsx  # Product detail
│       ├── (marketing)/     # About, artists
│       └── layout.tsx       # Root layout with fonts, RTL
├── components/
│   ├── ui/                  # Glass cards, buttons, modals
│   ├── layout/              # Navbar, footer
│   ├── home/                # Homepage scroll sections
│   ├── product/             # Cards, gallery, info panel
│   └── shared/              # Trust strip, search, etc.
├── lib/
│   ├── utils.ts             # cn(), t(), formatPrice()
│   └── i18n/                # next-intl config
├── sanity/
│   ├── schemas/             # Vibe, Occasion, Artist, Design, Homepage
│   └── lib/                 # Client + GROQ queries
├── styles/
│   └── globals.css          # Tailwind v4 + glassmorphism system
├── messages/
│   ├── en.json              # English UI strings
│   └── ar.json              # Arabic UI strings
└── types/
    └── index.ts             # Full type definitions
```

## Glassmorphism Design System

The brand guidelines v2.0 glassmorphism layer is implemented as CSS utility classes in `globals.css`:

| Class | Use |
|-------|-----|
| `.glass` | Default frosted surface (product cards, panels) |
| `.glass-frost-blue` | Trust badges, info overlays |
| `.glass-soft-violet` | Mood/inner-world content cards |
| `.glass-warm-glow` | Gift cards, featured badges, CTA hover |
| `.glass-mint` | Success states, confirmation moments |
| `.glass-nav` | Fixed navigation bar (higher opacity) |
| `.glass-modal` | Modals and overlays (highest opacity) |
| `.glass-hover` | Add hover lift + glow effect |

All glass classes auto-reduce blur on mobile (`@media max-width: 768px`) for performance.

## Getting Started

### 1. Clone and install

```bash
git clone <repo-url> horo-mvp
cd horo-mvp
npm install
```

### 2. Set up environment

```bash
cp .env.example .env.local
# Fill in your Sanity, Cloudinary, and Medusa credentials
```

### 3. Set up Sanity

```bash
npm create sanity@latest -- --project-id <your-id> --dataset production
# Copy schemas from src/sanity/schemas/ into your Sanity studio
```

### 4. Download fonts

Download and place in `public/fonts/`:
- [Space Grotesk Variable](https://fonts.google.com/specimen/Space+Grotesk) → `SpaceGrotesk-Variable.woff2`
- [Inter Variable](https://fonts.google.com/specimen/Inter) → `Inter-Variable.woff2`

### 5. Run dev

```bash
npm run dev
```

### 6. Deploy to Vercel

```bash
npx vercel
```

## Key Architecture Decisions

### Animation Split: Motion + GSAP
- **Motion** handles all React component animations (hover, mount/unmount, layout, gestures)
- **GSAP + ScrollTrigger** handles scroll-driven storytelling (parallax hero, staggered reveals, pinned sections)
- They coexist cleanly: Motion operates on React state, GSAP operates on DOM refs via `useGSAP`

### Bilingual Strategy (from Brand Guidelines v2.0)
- Brand identity (name, tagline, product names) → English always
- Commerce (DMs, ads, social, product descriptions) → Arabic-led
- `next-intl` handles routing (`/en/...` and `/ar/...`)
- Sanity stores content in both languages natively
- RTL layout switches automatically via `dir="rtl"` on `<html>`

### 3-Axis Product Navigation (from Guidelines v2.0)
- **Shop by Vibe**: Bold & Loud, Soft & Thoughtful, Proud & Rooted, Weird & Wonderful, Cosmic
- **Shop by Occasion**: Gift Something Real, Graduation, Eid & Ramadan, Birthday, Just Because
- **Browse by Artist**: Artist profiles with portfolios
- Every design is cross-tagged across all three axes in Sanity

## MVP Milestones

| Week | Milestone |
|------|-----------|
| 1-2 | Sanity schemas populated, homepage scroll storytelling, glassmorphism system live |
| 3-4 | Product pages, size guide, gallery, Medusa backend connected |
| 5-6 | Paymob payment + Bosta shipping integration, COD flow |
| 7-8 | WhatsApp order notifications, PostHog analytics, Meta/TikTok pixels |
| 9-10 | Arabic content, RTL testing, performance optimization |
| 11-12 | QA, soft launch, first paid acquisition test |

## Brand Guidelines Reference

This codebase implements HORO Brand Guidelines v2.0 (March 2026). Key specs:
- **Core palette**: Obsidian #1A1A1A, Papyrus #F5F0E8, Ember #E8593C, Deep Teal #2D7A9C
- **Glass frost layer**: Glass White #F8F6F2, Frost Blue #E3EFF5, Soft Violet #EDE5F5, Warm Glow #FFF5E6, Mint Frost #E6F5EF
- **Typography**: Space Grotesk (display, 500/700) + Inter (body, 400/500)
- **Glassmorphism specs**: backdrop-blur 16px, opacity 15-35%, border-radius 16px, shadow 0 8px 32px rgba(26,26,26,0.08)
- **Price anchor**: 799 EGP (standard), 899-999 EGP (premium drops), 649 EGP (acquisition test only)
