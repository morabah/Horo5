import { notFound } from "next/navigation";
import { getLocale, getTranslations } from "next-intl/server";
import { sanityClient, QUERIES } from "@/sanity/lib/client";
import { ProductGallery } from "@/components/product/product-gallery";
import { ProductInfo } from "@/components/product/product-info";
import { TrustStrip } from "@/components/product/trust-strip";
import type { Locale } from "@/types";

interface Props {
  params: Promise<{ slug: string; locale: string }>;
}

export default async function ProductPage({ params }: Props) {
  const { slug, locale } = await params;
  const design = await sanityClient.fetch(QUERIES.design(slug));

  if (!design) notFound();

  return (
    <div className="pt-20">
      {/* Main product layout */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">
          {/* Left: Image Gallery */}
          <ProductGallery design={design} />

          {/* Right: Product Info (glassmorphic sticky panel) */}
          <div className="lg:sticky lg:top-24 lg:self-start">
            <ProductInfo design={design} locale={locale as Locale} />
          </div>
        </div>
      </div>

      {/* Trust Strip */}
      <TrustStrip />
    </div>
  );
}
