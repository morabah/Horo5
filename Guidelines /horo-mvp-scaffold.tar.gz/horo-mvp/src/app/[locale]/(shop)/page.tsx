import { getTranslations } from "next-intl/server";
import { sanityClient, QUERIES } from "@/sanity/lib/client";
import { HeroSection } from "@/components/home/hero-section";
import { FeelingSection } from "@/components/home/feeling-section";
import { VibesGrid } from "@/components/home/vibes-grid";
import { ProofStrip } from "@/components/home/proof-strip";
import { CustomerStories } from "@/components/home/customer-stories";
import { LatestDrop } from "@/components/home/latest-drop";
import { InviteSection } from "@/components/home/invite-section";

export default async function HomePage() {
  const [homepage, vibes, featured] = await Promise.all([
    sanityClient.fetch(QUERIES.homepage),
    sanityClient.fetch(QUERIES.vibes),
    sanityClient.fetch(QUERIES.featuredDesigns),
  ]);

  return (
    <div className="flex flex-col">
      {/* 1. Hero (0–100vh) */}
      <HeroSection data={homepage?.hero} />

      {/* 2. The Feeling (100–200vh) */}
      <FeelingSection data={homepage?.feelingSection} />

      {/* 3. The Vibes (200–300vh) */}
      <VibesGrid vibes={vibes} />

      {/* 4. The Proof (300–400vh) */}
      <ProofStrip badges={homepage?.trustBadges} />

      {/* 5. Customer Stories (400–500vh) */}
      <CustomerStories stories={homepage?.customerStories} />

      {/* 6. Latest Drop (500–600vh) */}
      <LatestDrop designs={featured} />

      {/* 7. The Invite (600vh+) */}
      <InviteSection />
    </div>
  );
}
