import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import type { LocaleString, LocaleText, Locale } from "@/types";

/** Merge Tailwind classes safely */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Get localized string based on current locale */
export function t(value: LocaleString | LocaleText | undefined, locale: Locale): string {
  if (!value) return "";
  return value[locale] || value.en || "";
}

/** Format price in EGP */
export function formatPrice(amount: number): string {
  // Medusa stores in piasters (smallest unit)
  const egp = amount / 100;
  return new Intl.NumberFormat("en-EG", {
    style: "currency",
    currency: "EGP",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(egp);
}

/** Size guide data (HORO unisex tees) */
export const SIZE_GUIDE = [
  { size: "S",   chest: "96 cm",  length: "68 cm", shoulder: "44 cm" },
  { size: "M",   chest: "100 cm", length: "70 cm", shoulder: "46 cm" },
  { size: "L",   chest: "106 cm", length: "72 cm", shoulder: "48 cm" },
  { size: "XL",  chest: "112 cm", length: "74 cm", shoulder: "50 cm" },
  { size: "XXL", chest: "118 cm", length: "76 cm", shoulder: "52 cm" },
];

/** HORO brand constants */
export const BRAND = {
  name: "HORO",
  tagline: "Wear What You Mean",
  instagram: "https://instagram.com/horo.egypt",
  tiktok: "https://tiktok.com/@horo.egypt",
  whatsapp: "https://wa.me/20XXXXXXXXXX", // TODO: add real number
} as const;
