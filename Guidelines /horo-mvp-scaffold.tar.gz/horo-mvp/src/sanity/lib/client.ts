import { createClient } from "@sanity/client";
import imageUrlBuilder from "@sanity/image-url";
import type { SanityImage } from "@/types";

export const sanityClient = createClient({
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID!,
  dataset: process.env.NEXT_PUBLIC_SANITY_DATASET || "production",
  apiVersion: "2026-03-20",
  useCdn: process.env.NODE_ENV === "production",
});

const builder = imageUrlBuilder(sanityClient);

export function urlFor(source: SanityImage) {
  return builder.image(source);
}

// ─── GROQ Queries ───

export const QUERIES = {
  // Homepage singleton
  homepage: `*[_type == "homepage"][0]{
    hero,
    feelingSection,
    featuredVibes[]->{ _id, slug, name, tagline, heroImage, accentColor, order },
    trustBadges,
    customerStories[]{ name, quote, image, designRef->{ _id, slug, name, images } }
  }`,

  // All vibes for navigation
  vibes: `*[_type == "vibe"] | order(order asc) {
    _id, slug, name, tagline, heroImage, accentColor, order
  }`,

  // All occasions
  occasions: `*[_type == "occasion"] | order(order asc) {
    _id, slug, name, tagline, heroImage, order
  }`,

  // Designs by vibe
  designsByVibe: (vibeSlug: string) =>
    `*[_type == "design" && "${vibeSlug}" in vibes[]->slug.current]{
      _id, slug, name, story, featured, launchDate,
      artist->{ _id, name, slug, avatar },
      vibes[]->{ _id, slug, name },
      occasions[]->{ _id, slug, name },
      images { flatLay, onBody, printCloseUp },
      medusaProductId
    }`,

  // Designs by occasion
  designsByOccasion: (occasionSlug: string) =>
    `*[_type == "design" && "${occasionSlug}" in occasions[]->slug.current]{
      _id, slug, name, story, featured,
      artist->{ _id, name, slug, avatar },
      images { flatLay, onBody, printCloseUp },
      medusaProductId
    }`,

  // Single design (product page)
  design: (slug: string) =>
    `*[_type == "design" && slug.current == "${slug}"][0]{
      _id, slug, name, story, featured, launchDate,
      artist->{ _id, name, slug, bio, avatar, style, portfolioUrl },
      vibes[]->{ _id, slug, name, accentColor },
      occasions[]->{ _id, slug, name },
      images,
      medusaProductId
    }`,

  // All artists
  artists: `*[_type == "artist"] | order(name asc) {
    _id, slug, name, bio, avatar, style,
    "designCount": count(*[_type == "design" && references(^._id)])
  }`,

  // Featured designs (for homepage drops section)
  featuredDesigns: `*[_type == "design" && featured == true] | order(launchDate desc)[0...8]{
    _id, slug, name, story,
    artist->{ _id, name, avatar },
    images { flatLay, onBody },
    medusaProductId
  }`,
} as const;
