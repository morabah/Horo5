// ═══════════════════════════════════════════════════════════
// HORO Egypt — Sanity Schema Definitions
// Maps to brand guidelines v2.0 content model
// ═══════════════════════════════════════════════════════════

import { defineType, defineField } from "sanity";

// ─── Reusable: Bilingual String ───
const localeString = (name: string, title: string) => [
  defineField({ name: `${name}`, type: "object", title, fields: [
    defineField({ name: "en", type: "string", title: "English" }),
    defineField({ name: "ar", type: "string", title: "Arabic (العربية)" }),
  ]}),
];

const localeText = (name: string, title: string) => [
  defineField({ name: `${name}`, type: "object", title, fields: [
    defineField({ name: "en", type: "text", title: "English", rows: 3 }),
    defineField({ name: "ar", type: "text", title: "Arabic (العربية)", rows: 3 }),
  ]}),
];

// ─── Vibe (Primary Navigation Axis) ───
export const vibe = defineType({
  name: "vibe",
  title: "Vibe",
  type: "document",
  fields: [
    defineField({ name: "slug", type: "slug", title: "Slug", options: { source: "name.en" } }),
    ...localeString("name", "Vibe Name"),
    ...localeString("tagline", "Tagline"),
    ...localeText("description", "Description"),
    defineField({ name: "heroImage", type: "image", title: "Hero Image", options: { hotspot: true } }),
    defineField({ name: "accentColor", type: "string", title: "Accent Color (HEX)", description: "From brand palette e.g. #E8593C" }),
    defineField({ name: "order", type: "number", title: "Display Order" }),
  ],
  preview: { select: { title: "name.en", media: "heroImage" } },
});

// ─── Occasion (Secondary Navigation Axis) ───
export const occasion = defineType({
  name: "occasion",
  title: "Occasion",
  type: "document",
  fields: [
    defineField({ name: "slug", type: "slug", title: "Slug", options: { source: "name.en" } }),
    ...localeString("name", "Occasion Name"),
    ...localeString("tagline", "Tagline"),
    ...localeText("description", "Description"),
    defineField({ name: "heroImage", type: "image", title: "Hero Image", options: { hotspot: true } }),
    defineField({ name: "order", type: "number", title: "Display Order" }),
  ],
  preview: { select: { title: "name.en", media: "heroImage" } },
});

// ─── Artist ───
export const artist = defineType({
  name: "artist",
  title: "Artist",
  type: "document",
  fields: [
    defineField({ name: "slug", type: "slug", title: "Slug", options: { source: "name" } }),
    defineField({ name: "name", type: "string", title: "Name" }),
    ...localeText("bio", "Bio"),
    defineField({ name: "avatar", type: "image", title: "Avatar", options: { hotspot: true } }),
    defineField({ name: "portfolioUrl", type: "url", title: "Portfolio URL" }),
    ...localeString("style", "Art Style Description"),
  ],
  preview: { select: { title: "name", media: "avatar" } },
});

// ─── Design (core product content) ───
export const design = defineType({
  name: "design",
  title: "Design",
  type: "document",
  fields: [
    defineField({ name: "slug", type: "slug", title: "Slug", options: { source: "name.en" } }),
    ...localeString("name", "Design Name"),
    ...localeText("story", "Design Story (\"For the one who...\")"),
    defineField({ name: "artist", type: "reference", title: "Artist", to: [{ type: "artist" }] }),
    defineField({ name: "vibes", type: "array", title: "Vibes", of: [{ type: "reference", to: [{ type: "vibe" }] }], description: "Cross-tag across navigation axes" }),
    defineField({ name: "occasions", type: "array", title: "Occasions", of: [{ type: "reference", to: [{ type: "occasion" }] }] }),
    defineField({
      name: "images",
      type: "object",
      title: "Product Images (minimum 5 required)",
      fields: [
        defineField({ name: "flatLay", type: "image", title: "1. Flat Lay", options: { hotspot: true }, validation: (r) => r.required() }),
        defineField({ name: "onBody", type: "image", title: "2. On-Body Front", options: { hotspot: true }, validation: (r) => r.required() }),
        defineField({ name: "lifestyle", type: "image", title: "3. Lifestyle / Street", options: { hotspot: true }, validation: (r) => r.required() }),
        defineField({ name: "printCloseUp", type: "image", title: "4. Print Close-Up Detail", options: { hotspot: true }, validation: (r) => r.required() }),
        defineField({ name: "sizeReference", type: "image", title: "5. Size Reference (with model measurements)", options: { hotspot: true }, validation: (r) => r.required() }),
      ],
    }),
    defineField({ name: "medusaProductId", type: "string", title: "Medusa Product ID", description: "Links to commerce backend" }),
    defineField({ name: "featured", type: "boolean", title: "Featured", initialValue: false }),
    defineField({ name: "launchDate", type: "date", title: "Launch Date" }),
  ],
  preview: {
    select: { title: "name.en", subtitle: "artist.name", media: "images.flatLay" },
  },
});

// ─── Homepage ───
export const homepage = defineType({
  name: "homepage",
  title: "Homepage",
  type: "document",
  fields: [
    defineField({
      name: "hero",
      type: "object",
      title: "Hero Section",
      fields: [
        ...localeString("tagline", "Tagline"),
        ...localeString("subline", "Subline"),
        defineField({ name: "media", type: "image", title: "Hero Image/Video Poster" }),
        defineField({ name: "videoUrl", type: "url", title: "Hero Video URL (optional)" }),
        ...localeString("ctaText", "CTA Button Text"),
      ],
    }),
    defineField({
      name: "feelingSection",
      type: "object",
      title: "\"The Feeling\" Section",
      fields: [
        ...localeString("headline", "Headline"),
        ...localeText("body", "Body Text"),
      ],
    }),
    defineField({ name: "featuredVibes", type: "array", title: "Featured Vibes", of: [{ type: "reference", to: [{ type: "vibe" }] }] }),
    defineField({
      name: "trustBadges",
      type: "array",
      title: "Trust Badges",
      of: [{
        type: "object",
        fields: [
          defineField({ name: "icon", type: "string", title: "Icon Name (lucide)" }),
          ...localeString("text", "Badge Text"),
        ],
      }],
    }),
    defineField({
      name: "customerStories",
      type: "array",
      title: "Customer Stories",
      of: [{
        type: "object",
        fields: [
          defineField({ name: "name", type: "string", title: "Customer Name" }),
          ...localeString("quote", "Quote"),
          defineField({ name: "image", type: "image", title: "Customer Photo", options: { hotspot: true } }),
          defineField({ name: "designRef", type: "reference", title: "Design Worn", to: [{ type: "design" }] }),
        ],
      }],
    }),
  ],
  // Singleton: only one homepage document
  preview: { prepare: () => ({ title: "Homepage" }) },
});

// ─── Schema Index ───
export const schemaTypes = [vibe, occasion, artist, design, homepage];
