"use client";

import { motion, type HTMLMotionProps } from "motion/react";
import { cn } from "@/lib/utils";

type GlassVariant = "default" | "frost-blue" | "soft-violet" | "warm-glow" | "mint" | "modal";

interface GlassCardProps extends HTMLMotionProps<"div"> {
  variant?: GlassVariant;
  hover?: boolean;
  children: React.ReactNode;
}

const variantClasses: Record<GlassVariant, string> = {
  default: "glass",
  "frost-blue": "glass-frost-blue",
  "soft-violet": "glass-soft-violet",
  "warm-glow": "glass-warm-glow",
  mint: "glass-mint",
  modal: "glass-modal",
};

export function GlassCard({
  variant = "default",
  hover = true,
  className,
  children,
  ...motionProps
}: GlassCardProps) {
  return (
    <motion.div
      className={cn(
        variantClasses[variant],
        hover && "glass-hover",
        className
      )}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      {...motionProps}
    >
      {children}
    </motion.div>
  );
}
