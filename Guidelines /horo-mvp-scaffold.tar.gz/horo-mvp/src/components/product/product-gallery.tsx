"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import type { Design } from "@/types";

export function ProductGallery({ design }: { design: Design }) {
  const imageKeys = ["flatLay", "onBody", "lifestyle", "printCloseUp", "sizeReference"] as const;
  const [active, setActive] = useState(0);

  return (
    <div className="flex flex-col gap-4">
      {/* Main image */}
      <div className="relative aspect-[3/4] rounded-[var(--radius-glass-lg)] overflow-hidden bg-stone/20">
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            className="absolute inset-0 bg-stone/30"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* TODO: Replace with Next/Image + urlFor(design.images[imageKeys[active]]) */}
            <div className="absolute inset-0 flex items-center justify-center type-small text-clay-earth">
              {imageKeys[active].replace(/([A-Z])/g, " $1").trim()}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Thumbnail strip */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {imageKeys.map((key, i) => (
          <button
            key={key}
            onClick={() => setActive(i)}
            className={`flex-shrink-0 w-16 h-20 sm:w-20 sm:h-24 rounded-[var(--radius-glass-sm)] overflow-hidden bg-stone/20 border-2 transition-colors duration-200 ${
              i === active
                ? "border-ember"
                : "border-transparent hover:border-desert-sand/50"
            }`}
          >
            {/* TODO: Thumbnail image */}
            <div className="w-full h-full flex items-center justify-center text-[9px] text-clay-earth">
              {i + 1}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
