"use client";

import Link from "next/link";
import { motion } from "motion/react";
import type { Design, Locale } from "@/types";
import { t as loc } from "@/lib/utils";

interface ProductCardProps {
  design: Design;
  locale: Locale;
}

export function ProductCard({ design, locale }: ProductCardProps) {
  const slug = design.slug?.current || design.slug;

  return (
    <Link href={`/${locale}/products/${slug}`} className="group block">
      <motion.div
        className="relative overflow-hidden rounded-[var(--radius-glass)] bg-stone/20"
        whileHover={{ y: -4 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      >
        {/* Product Image */}
        <div className="aspect-[3/4] bg-stone/30 relative overflow-hidden">
          {/* TODO: Replace with Next/Image + urlFor(design.images.flatLay) */}
          <div className="absolute inset-0 bg-gradient-to-t from-obsidian/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

          {/* Quick-view glassmorphic overlay on hover */}
          <div className="absolute bottom-0 inset-x-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]">
            <div className="glass p-3 text-center">
              <span className="type-small font-medium text-obsidian">
                {locale === "ar" ? "عرض سريع" : "Quick View"}
              </span>
            </div>
          </div>
        </div>

        {/* Info */}
        <div className="p-4">
          {/* Artist credit */}
          {design.artist && (
            <p className="type-small text-clay-earth mb-1">
              {design.artist.name}
            </p>
          )}

          {/* Design name */}
          <h3 className="type-h3 text-obsidian line-clamp-1 mb-1">
            {loc(design.name, locale)}
          </h3>

          {/* Story teaser */}
          <p className="type-small text-clay-earth line-clamp-1 mb-3">
            {loc(design.story, locale)}
          </p>

          {/* Price — hardcoded for now, connect to Medusa */}
          <p className="font-display font-bold text-obsidian">
            799 EGP
          </p>
        </div>
      </motion.div>
    </Link>
  );
}
