"use client";

import { useTranslations, useLocale } from "next-intl";
import { Shield, Palette, RefreshCw, Truck } from "lucide-react";

export function TrustStrip() {
  const t = useTranslations("product.trustBadge");

  const badges = [
    { icon: <Shield className="w-5 h-5" />, text: t("cotton") },
    { icon: <Palette className="w-5 h-5" />, text: t("artist") },
    { icon: <RefreshCw className="w-5 h-5" />, text: t("exchange") },
    { icon: <Truck className="w-5 h-5" />, text: t("cod") },
  ];

  return (
    <div className="border-y border-stone/30 bg-papyrus">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-wrap justify-center gap-6 sm:gap-10">
          {badges.map((badge, i) => (
            <div key={i} className="flex items-center gap-2 text-clay-earth">
              {badge.icon}
              <span className="type-small font-medium">{badge.text}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
