"use client";

import { useState } from "react";
import { useTranslations } from "next-intl";
import { motion } from "motion/react";
import { ShoppingBag, Ruler, User } from "lucide-react";
import { GlassCard } from "@/components/ui/glass-card";
import { cn, t as loc, SIZE_GUIDE } from "@/lib/utils";
import type { Design, Locale } from "@/types";

interface ProductInfoProps {
  design: Design;
  locale: Locale;
}

const sizes = ["S", "M", "L", "XL", "XXL"];

export function ProductInfo({ design, locale }: ProductInfoProps) {
  const t = useTranslations("product");
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [showSizeGuide, setShowSizeGuide] = useState(false);

  return (
    <div className="flex flex-col gap-6">
      {/* Artist credit */}
      {design.artist && (
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-stone/40 flex items-center justify-center">
            <User className="w-4 h-4 text-clay-earth" />
          </div>
          <div>
            <p className="type-small text-clay-earth">{t("artistCredit")}</p>
            <p className="type-body font-medium text-obsidian">{design.artist.name}</p>
          </div>
        </div>
      )}

      {/* Design name */}
      <h1 className="font-display text-2xl sm:text-3xl font-bold text-obsidian">
        {loc(design.name, locale)}
      </h1>

      {/* Price */}
      <p className="font-display text-2xl font-bold text-obsidian">
        799 EGP
        {/* TODO: Fetch from Medusa via design.medusaProductId */}
      </p>

      {/* Design story */}
      <GlassCard variant="soft-violet" hover={false} className="p-5">
        <p className="type-small text-dusk-violet font-medium mb-1">
          {t("forTheOneWho")}
        </p>
        <p className="type-body text-obsidian">
          {loc(design.story, locale)}
        </p>
      </GlassCard>

      {/* Size selector */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="type-body font-medium text-obsidian">{t("selectSize")}</span>
          <button
            onClick={() => setShowSizeGuide(!showSizeGuide)}
            className="type-small text-deep-teal hover:text-obsidian transition-colors flex items-center gap-1"
          >
            <Ruler className="w-3.5 h-3.5" />
            {t("sizeGuide")}
          </button>
        </div>

        <div className="flex gap-2">
          {sizes.map((size) => (
            <button
              key={size}
              onClick={() => setSelectedSize(size)}
              className={cn(
                "flex-1 py-3 rounded-[var(--radius-glass-sm)] border-2 font-display font-medium text-sm transition-all duration-200",
                selectedSize === size
                  ? "border-ember bg-ember/5 text-ember"
                  : "border-stone/50 text-warm-charcoal hover:border-desert-sand"
              )}
            >
              {size}
            </button>
          ))}
        </div>

        {/* Size guide dropdown */}
        {showSizeGuide && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 glass-frost-blue p-4 overflow-hidden"
          >
            <table className="w-full type-small">
              <thead>
                <tr className="text-clay-earth">
                  <th className="text-start pb-2">{locale === "ar" ? "المقاس" : "Size"}</th>
                  <th className="text-start pb-2">{locale === "ar" ? "الصدر" : "Chest"}</th>
                  <th className="text-start pb-2">{locale === "ar" ? "الطول" : "Length"}</th>
                  <th className="text-start pb-2">{locale === "ar" ? "الكتف" : "Shoulder"}</th>
                </tr>
              </thead>
              <tbody>
                {SIZE_GUIDE.map((row) => (
                  <tr
                    key={row.size}
                    className={cn(
                      "border-t border-stone/20",
                      selectedSize === row.size && "text-ember font-medium"
                    )}
                  >
                    <td className="py-2">{row.size}</td>
                    <td className="py-2">{row.chest}</td>
                    <td className="py-2">{row.length}</td>
                    <td className="py-2">{row.shoulder}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </motion.div>
        )}
      </div>

      {/* Add to Cart CTA — sticky on mobile */}
      <motion.button
        className={cn(
          "btn-ember w-full py-4 text-base",
          !selectedSize && "opacity-60 cursor-not-allowed"
        )}
        disabled={!selectedSize}
        whileTap={{ scale: 0.98 }}
      >
        <ShoppingBag className="w-5 h-5" />
        {t("addToCart")}
      </motion.button>

      {/* Mobile sticky CTA */}
      <div className="fixed bottom-0 inset-x-0 p-4 glass-nav lg:hidden z-40">
        <button
          className={cn(
            "btn-ember w-full py-4 text-base",
            !selectedSize && "opacity-60 cursor-not-allowed"
          )}
          disabled={!selectedSize}
        >
          <ShoppingBag className="w-5 h-5 inline mr-2" />
          {t("addToCart")} — 799 EGP
        </button>
      </div>
    </div>
  );
}
