"use client";

import Link from "next/link";
import { useLocale } from "next-intl";
import { motion } from "motion/react";

export function InviteSection() {
  const locale = useLocale();

  return (
    <section className="py-32 px-6 text-center">
      <motion.div
        className="max-w-xl mx-auto"
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      >
        <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-obsidian mb-6">
          {locale === "ar" ? "لاقي كلمتك." : "Find your word."}
        </h2>
        <p className="type-body text-clay-earth text-lg mb-10">
          {locale === "ar"
            ? "كل تصميم كلمة. كل ثيم قواعد. الكولكشن لغة. وانت اللي بتتكلم."
            : "Every design is a word. Every theme is a grammar. The collection is a language. You are the speaker."}
        </p>
        <Link href={`/${locale}/vibes`} className="btn-ember text-lg px-10 py-4">
          {locale === "ar" ? "اكتشف الكولكشن" : "Explore the Collection"}
        </Link>
      </motion.div>
    </section>
  );
}
