"use client";

import { useRef } from "react";
import { useLocale, useTranslations } from "next-intl";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

interface FeelingData {
  headline?: { en: string; ar: string };
  body?: { en: string; ar: string };
}

export function FeelingSection({ data }: { data?: FeelingData }) {
  const t = useTranslations("feeling");
  const locale = useLocale() as "en" | "ar";
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);

  useGSAP(
    () => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 70%",
          end: "center center",
          scrub: 0.8,
        },
      });

      tl.from(headlineRef.current, {
        opacity: 0,
        y: 60,
        duration: 1,
      }).from(
        bodyRef.current,
        { opacity: 0, y: 40, duration: 1 },
        "-=0.5"
      );
    },
    { scope: sectionRef }
  );

  return (
    <section
      ref={sectionRef}
      className="min-h-[80vh] flex items-center justify-center px-6"
    >
      <div className="max-w-2xl text-center">
        <h2
          ref={headlineRef}
          className="font-display text-3xl sm:text-4xl md:text-5xl font-bold text-obsidian leading-tight"
        >
          {data?.headline?.[locale] || t("headline")}
        </h2>
        <p
          ref={bodyRef}
          className="mt-8 type-body text-lg sm:text-xl text-clay-earth leading-relaxed"
        >
          {data?.body?.[locale] || t("body")}
        </p>
      </div>
    </section>
  );
}
