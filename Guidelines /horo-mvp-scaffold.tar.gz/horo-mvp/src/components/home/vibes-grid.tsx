"use client";

import { useRef } from "react";
import Link from "next/link";
import { useLocale } from "next-intl";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { GlassCard } from "@/components/ui/glass-card";
import type { Vibe, Locale } from "@/types";
import { t as loc } from "@/lib/utils";

gsap.registerPlugin(ScrollTrigger);

export function VibesGrid({ vibes }: { vibes: Vibe[] }) {
  const locale = useLocale() as Locale;
  const gridRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const cards = gridRef.current?.querySelectorAll(".vibe-card");
      if (!cards) return;

      gsap.from(cards, {
        opacity: 0,
        y: 80,
        scale: 0.95,
        stagger: 0.12,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: gridRef.current,
          start: "top 75%",
          toggleActions: "play none none none",
        },
      });
    },
    { scope: gridRef }
  );

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <h2 className="type-label text-center mb-12 text-desert-sand">
          {locale === "ar" ? "اختار الـ Vibe بتاعك" : "Find Your Vibe"}
        </h2>

        <div
          ref={gridRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {vibes?.map((vibe) => (
            <Link
              key={vibe._id}
              href={`/${locale}/vibes/${vibe.slug?.current || vibe.slug}`}
              className="vibe-card group block"
            >
              <GlassCard
                hover
                className="relative overflow-hidden aspect-[4/5] p-0"
                whileHover={{ scale: 1.02 }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              >
                {/* Background image */}
                <div className="absolute inset-0 bg-obsidian">
                  {/* TODO: Replace with Sanity image via urlFor(vibe.heroImage) */}
                  <div
                    className="absolute inset-0 opacity-60 bg-gradient-to-t from-obsidian via-obsidian/20 to-transparent"
                  />
                </div>

                {/* Content overlay */}
                <div className="relative h-full flex flex-col justify-end p-8">
                  {/* Accent dot */}
                  <div
                    className="w-3 h-3 rounded-full mb-4"
                    style={{ backgroundColor: vibe.accentColor || "#E8593C" }}
                  />

                  <h3 className="font-display text-2xl sm:text-3xl font-bold text-clean-white mb-2">
                    {loc(vibe.name, locale)}
                  </h3>

                  <p className="type-body text-stone/80 line-clamp-2">
                    {loc(vibe.tagline, locale)}
                  </p>

                  {/* Hover reveal arrow */}
                  <div className="mt-4 flex items-center gap-2 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                    <span className="type-small text-clean-white font-medium">
                      {locale === "ar" ? "اكتشف" : "Explore"}
                    </span>
                    <svg
                      className="w-4 h-4 text-clean-white rtl:rotate-180"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </div>
                </div>
              </GlassCard>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
