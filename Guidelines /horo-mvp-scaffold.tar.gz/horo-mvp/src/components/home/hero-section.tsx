"use client";

import { useRef } from "react";
import { useLocale, useTranslations } from "next-intl";
import { motion } from "motion/react";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Link from "next/link";
import { ArrowDown } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

interface HeroData {
  tagline?: { en: string; ar: string };
  subline?: { en: string; ar: string };
  ctaText?: { en: string; ar: string };
  videoUrl?: string;
}

export function HeroSection({ data }: { data?: HeroData }) {
  const t = useTranslations("hero");
  const locale = useLocale();
  const containerRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      // Parallax: background moves slower than scroll
      gsap.to(bgRef.current, {
        yPercent: 30,
        ease: "none",
        scrollTrigger: {
          trigger: containerRef.current,
          start: "top top",
          end: "bottom top",
          scrub: 1,
        },
      });

      // Text fades out on scroll
      gsap.to(textRef.current, {
        opacity: 0,
        y: -60,
        ease: "none",
        scrollTrigger: {
          trigger: containerRef.current,
          start: "30% top",
          end: "80% top",
          scrub: 1,
        },
      });
    },
    { scope: containerRef }
  );

  return (
    <section
      ref={containerRef}
      className="relative h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background layer (parallax target) */}
      <div
        ref={bgRef}
        className="absolute inset-0 -top-[10%] -bottom-[10%] bg-obsidian"
      >
        {/* TODO: Replace with Cloudinary/Sanity hero image or video */}
        <div className="absolute inset-0 bg-gradient-to-b from-obsidian/60 via-obsidian/30 to-papyrus" />

        {/* Warm grain overlay for texture */}
        <div
          className="absolute inset-0 opacity-[0.03] mix-blend-multiply"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
          }}
        />
      </div>

      {/* Content */}
      <div ref={textRef} className="relative z-10 text-center px-6 max-w-3xl">
        {/* Tagline */}
        <motion.h1
          className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-clean-white tracking-tight"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
        >
          {data?.tagline?.[locale as "en" | "ar"] || t("tagline")}
        </motion.h1>

        {/* Subline */}
        <motion.p
          className="mt-6 type-body text-stone text-lg sm:text-xl max-w-xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
        >
          {data?.subline?.[locale as "en" | "ar"] || t("subline")}
        </motion.p>

        {/* Glassmorphic CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="mt-10"
        >
          <Link href={`/${locale}/vibes`} className="btn-ember text-base sm:text-lg px-8 py-4">
            {data?.ctaText?.[locale as "en" | "ar"] || t("cta")}
          </Link>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
        >
          <ArrowDown className="w-5 h-5 text-stone/60" />
        </motion.div>
      </motion.div>
    </section>
  );
}
