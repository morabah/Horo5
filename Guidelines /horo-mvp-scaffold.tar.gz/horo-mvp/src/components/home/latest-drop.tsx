"use client";

import { useRef } from "react";
import Link from "next/link";
import { useLocale } from "next-intl";
import { useGSAP } from "@gsap/react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ProductCard } from "@/components/product/product-card";
import type { Design, Locale } from "@/types";

gsap.registerPlugin(ScrollTrigger);

export function LatestDrop({ designs }: { designs?: Design[] }) {
  const locale = useLocale() as Locale;
  const gridRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const cards = gridRef.current?.querySelectorAll(".product-card");
      if (!cards) return;

      gsap.from(cards, {
        opacity: 0,
        y: 60,
        stagger: 0.08,
        duration: 0.7,
        ease: "power3.out",
        scrollTrigger: {
          trigger: gridRef.current,
          start: "top 80%",
          toggleActions: "play none none none",
        },
      });
    },
    { scope: gridRef }
  );

  if (!designs?.length) return null;

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex items-center justify-between mb-12">
          <h2 className="type-label text-desert-sand">
            {locale === "ar" ? "أحدث الإصدارات" : "Latest Drop"}
          </h2>
          <Link
            href={`/${locale}/vibes`}
            className="type-small text-deep-teal hover:text-obsidian transition-colors font-medium"
          >
            {locale === "ar" ? "شوف الكل" : "View All"} →
          </Link>
        </div>

        <div
          ref={gridRef}
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6"
        >
          {designs.map((design) => (
            <div key={design._id} className="product-card">
              <ProductCard design={design} locale={locale} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
