"use client";

import { useLocale, useTranslations } from "next-intl";
import { motion } from "motion/react";
import { Shield, Palette, Truck, RefreshCw } from "lucide-react";
import type { Locale } from "@/types";
import { t as loc } from "@/lib/utils";

const fallbackBadges = [
  { icon: "cotton", key: "cotton" },
  { icon: "artist", key: "artist" },
  { icon: "exchange", key: "exchange" },
  { icon: "cod", key: "cod" },
] as const;

const iconMap: Record<string, React.ReactNode> = {
  cotton: <Shield className="w-6 h-6" />,
  artist: <Palette className="w-6 h-6" />,
  exchange: <RefreshCw className="w-6 h-6" />,
  cod: <Truck className="w-6 h-6" />,
};

interface ProofStripProps {
  badges?: { icon: string; text: { en: string; ar: string } }[];
}

export function ProofStrip({ badges }: ProofStripProps) {
  const t = useTranslations("product.trustBadge");
  const locale = useLocale() as Locale;

  const items = badges || fallbackBadges.map((b) => ({
    icon: b.icon,
    text: { en: t(b.key), ar: t(b.key) },
  }));

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-obsidian">
      <div className="mx-auto max-w-5xl">
        <h2 className="type-label text-center mb-12 text-desert-sand">
          {locale === "ar" ? "ليه HORO؟" : "Why HORO?"}
        </h2>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {items.map((badge, i) => (
            <motion.div
              key={i}
              className="glass-frost-blue p-6 text-center"
              style={{ background: "rgba(227, 239, 245, 0.08)", borderColor: "rgba(255,255,255,0.08)" }}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="flex justify-center mb-4 text-desert-sand">
                {iconMap[badge.icon] || <Shield className="w-6 h-6" />}
              </div>
              <p className="type-small text-stone font-medium">
                {typeof badge.text === "string" ? badge.text : loc(badge.text, locale)}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
