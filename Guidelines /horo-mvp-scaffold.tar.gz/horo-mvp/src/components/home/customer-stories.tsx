"use client";

import { useLocale } from "next-intl";
import { motion } from "motion/react";
import { GlassCard } from "@/components/ui/glass-card";
import { Quote } from "lucide-react";
import type { Locale } from "@/types";
import { t as loc } from "@/lib/utils";

interface Story {
  name: string;
  quote: { en: string; ar: string };
  image?: any;
  designRef?: any;
}

export function CustomerStories({ stories }: { stories?: Story[] }) {
  const locale = useLocale() as Locale;

  if (!stories?.length) return null;

  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <h2 className="type-label text-center mb-12 text-desert-sand">
          {locale === "ar" ? "قصص حقيقية" : "Real Stories"}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stories.map((story, i) => (
            <GlassCard
              key={i}
              variant="warm-glow"
              className="p-8"
              transition={{ delay: i * 0.1, duration: 0.5 }}
            >
              <Quote className="w-8 h-8 text-desert-sand/40 mb-4" />
              <blockquote className="type-body text-obsidian text-lg leading-relaxed mb-6">
                &ldquo;{loc(story.quote, locale)}&rdquo;
              </blockquote>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-stone/30" />
                <span className="type-small font-medium text-obsidian">
                  {story.name}
                </span>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </section>
  );
}
