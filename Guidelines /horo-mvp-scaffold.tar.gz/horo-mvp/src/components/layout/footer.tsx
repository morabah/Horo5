import Link from "next/link";
import { useLocale, useTranslations } from "next-intl";
import { Instagram } from "lucide-react";
import { BRAND } from "@/lib/utils";

export function Footer() {
  const t = useTranslations("footer");
  const locale = useLocale();
  const year = new Date().getFullYear();

  return (
    <footer className="bg-obsidian text-clean-white mt-auto">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <h3 className="font-display text-2xl font-bold mb-2">HORO</h3>
            <p className="type-body text-stone">{t("tagline")}</p>
          </div>

          {/* Links */}
          <div>
            <h4 className="type-label text-desert-sand mb-4">{t("contact")}</h4>
            <div className="flex flex-col gap-2">
              <a href={BRAND.whatsapp} target="_blank" rel="noopener" className="type-body text-stone hover:text-clean-white transition-colors">
                WhatsApp
              </a>
              <a href={`mailto:hello@horo.eg`} className="type-body text-stone hover:text-clean-white transition-colors">
                hello@horo.eg
              </a>
            </div>
          </div>

          {/* Social */}
          <div>
            <h4 className="type-label text-desert-sand mb-4">{t("followUs")}</h4>
            <div className="flex gap-4">
              <a href={BRAND.instagram} target="_blank" rel="noopener" className="p-2 rounded-full border border-warm-charcoal hover:border-desert-sand transition-colors">
                <Instagram className="w-5 h-5 text-stone" />
              </a>
              <a href={BRAND.tiktok} target="_blank" rel="noopener" className="p-2 rounded-full border border-warm-charcoal hover:border-desert-sand transition-colors">
                <svg className="w-5 h-5 text-stone" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.88-2.88 2.89 2.89 0 012.88-2.88c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 00-.79-.05A6.34 6.34 0 003.15 15.3a6.34 6.34 0 0010.86 4.48V13a8.28 8.28 0 005.58 2.16v-3.45a4.85 4.85 0 01-2.83-.93 4.86 4.86 0 01-2-4.09z"/></svg>
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-warm-charcoal">
          <p className="type-small text-warm-charcoal text-center">
            {t("rights", { year })}
          </p>
        </div>
      </div>
    </footer>
  );
}
