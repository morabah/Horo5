"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useLocale, useTranslations } from "next-intl";
import { motion, AnimatePresence } from "motion/react";
import { ShoppingBag, Search, Menu, X, Globe } from "lucide-react";
import { cn } from "@/lib/utils";

export function Navbar() {
  const t = useTranslations("nav");
  const locale = useLocale();
  const altLocale = locale === "en" ? "ar" : "en";
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navLinks = [
    { href: `/${locale}/vibes`, label: t("vibes") },
    { href: `/${locale}/occasions`, label: t("occasions") },
    { href: `/${locale}/artists`, label: t("artists") },
    { href: `/${locale}/about`, label: t("about") },
  ];

  return (
    <header
      className={cn(
        "fixed top-0 inset-x-0 z-50 transition-all duration-300",
        scrolled ? "glass-nav" : "bg-transparent"
      )}
    >
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link
            href={`/${locale}`}
            className="font-display text-xl font-bold tracking-tight text-obsidian"
          >
            HORO
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="type-small font-medium text-warm-charcoal hover:text-obsidian transition-colors duration-200"
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {/* Search */}
            <button
              aria-label="Search"
              className="p-2 rounded-full hover:bg-stone/30 transition-colors"
            >
              <Search className="w-5 h-5 text-warm-charcoal" />
            </button>

            {/* Language Toggle */}
            <Link
              href={`/${altLocale}`}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full glass text-xs font-medium text-warm-charcoal hover:text-obsidian transition-colors"
            >
              <Globe className="w-3.5 h-3.5" />
              {t("language")}
            </Link>

            {/* Cart */}
            <Link
              href={`/${locale}/cart`}
              className="relative p-2 rounded-full hover:bg-stone/30 transition-colors"
            >
              <ShoppingBag className="w-5 h-5 text-warm-charcoal" />
              {/* Cart count badge — connect to cart state */}
              {/* <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-ember text-white text-[10px] font-bold rounded-full flex items-center justify-center">2</span> */}
            </Link>

            {/* Mobile Menu Toggle */}
            <button
              aria-label="Menu"
              className="md:hidden p-2 rounded-full hover:bg-stone/30 transition-colors"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="md:hidden glass-modal mx-4 mb-4 overflow-hidden"
          >
            <div className="p-6 flex flex-col gap-4">
              {navLinks.map((link, i) => (
                <motion.div
                  key={link.href}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Link
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className="block py-2 type-h3 text-obsidian"
                  >
                    {link.label}
                  </Link>
                </motion.div>
              ))}
              <Link
                href={`/${altLocale}`}
                className="flex items-center gap-2 py-2 type-body text-clay-earth"
              >
                <Globe className="w-4 h-4" />
                {t("language")}
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
