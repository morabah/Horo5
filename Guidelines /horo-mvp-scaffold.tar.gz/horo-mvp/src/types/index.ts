// ═══════════════════════════════════════════════════════════
// HORO Egypt — Core Type Definitions
// Maps to Sanity schemas + Medusa commerce data
// ═══════════════════════════════════════════════════════════

// ─── Sanity Content Types ───

export type Locale = "en" | "ar";

export interface LocaleString {
  en: string;
  ar: string;
}

export interface LocaleText {
  en: string;
  ar: string;
}

export interface SanityImage {
  _type: "image";
  asset: {
    _ref: string;
    _type: "reference";
  };
  alt?: LocaleString;
  hotspot?: { x: number; y: number };
  crop?: { top: number; bottom: number; left: number; right: number };
}

// ─── Vibe (Primary Navigation Axis) ───

export type VibeSlug =
  | "bold-and-loud"
  | "soft-and-thoughtful"
  | "proud-and-rooted"
  | "weird-and-wonderful"
  | "cosmic";

export interface Vibe {
  _id: string;
  _type: "vibe";
  slug: string;
  name: LocaleString;
  tagline: LocaleString; // "For when you want to be noticed"
  description: LocaleText;
  heroImage: SanityImage;
  accentColor: string; // HEX from brand palette
  order: number;
}

// ─── Occasion (Secondary Navigation Axis) ───

export type OccasionSlug =
  | "gift-something-real"
  | "graduation-season"
  | "eid-and-ramadan"
  | "birthday-pick"
  | "just-because";

export interface Occasion {
  _id: string;
  _type: "occasion";
  slug: string;
  name: LocaleString;
  tagline: LocaleString;
  description: LocaleText;
  heroImage: SanityImage;
  order: number;
}

// ─── Artist ───

export interface Artist {
  _id: string;
  _type: "artist";
  slug: string;
  name: string;
  bio: LocaleText;
  avatar: SanityImage;
  portfolioUrl?: string;
  style: LocaleString; // "Surreal portraits", "Egyptian motifs"
  designs: Design[];
}

// ─── Design (the core product content) ───

export interface Design {
  _id: string;
  _type: "design";
  slug: string;
  name: LocaleString;
  story: LocaleText; // "For the one who..."
  artist: Artist;
  vibes: Vibe[]; // cross-tagged across axes
  occasions: Occasion[];
  images: {
    flatLay: SanityImage;
    onBody: SanityImage;
    lifestyle: SanityImage;
    printCloseUp: SanityImage;
    sizeReference: SanityImage;
  };
  medusaProductId: string; // links to Medusa commerce
  featured: boolean;
  launchDate: string;
}

// ─── Homepage Content ───

export interface HomepageContent {
  _id: string;
  _type: "homepage";
  hero: {
    tagline: LocaleString;
    subline: LocaleString;
    media: SanityImage; // or video URL
    ctaText: LocaleString;
  };
  feelingSection: {
    headline: LocaleString;
    body: LocaleText;
  };
  featuredVibes: Vibe[];
  proofSection: {
    headline: LocaleString;
    trustBadges: { icon: string; text: LocaleString }[];
    closeUpImages: SanityImage[];
  };
  customerStories: {
    name: string;
    quote: LocaleString;
    image: SanityImage;
    designRef: Design;
  }[];
}

// ─── Medusa Commerce Types ───

export interface Product {
  id: string;
  title: string;
  description: string;
  handle: string; // URL slug
  variants: ProductVariant[];
  images: { url: string; alt?: string }[];
  metadata?: {
    sanity_design_id?: string;
    artist_name?: string;
  };
}

export interface ProductVariant {
  id: string;
  title: string; // "M / Black", "L / White"
  prices: Price[];
  inventory_quantity: number;
  options: { value: string }[];
}

export interface Price {
  amount: number; // in piasters (79900 = 799 EGP)
  currency_code: string; // "EGP"
}

export interface CartItem {
  id: string;
  variant: ProductVariant;
  quantity: number;
  design?: Design; // enriched from Sanity
}

export interface Cart {
  id: string;
  items: CartItem[];
  total: number;
  subtotal: number;
  shipping_total: number;
}

// ─── UI State Types ───

export interface SizeGuide {
  size: string; // "S", "M", "L", "XL", "XXL"
  chest: string; // "96-100 cm"
  length: string;
  shoulder: string;
}

export type NavigationAxis = "vibe" | "occasion" | "artist";
