export type Vibe = {
  slug: string;
  name: string;
  tagline: string;
  count: number;
};

export type Occasion = {
  slug: string;
  name: string;
  description: string;
};

export type Artist = {
  slug: string;
  name: string;
  style: string;
  count: number;
};

export type Product = {
  slug: string;
  name: string;
  artist: string;
  artistSlug: string;
  vibe: string;
  vibeSlug: string;
  price: number;
  giftReady?: boolean;
  image: string;
  identityLine?: string;
};

export const vibes: Vibe[] = [
  { slug: 'emotions', name: 'Emotions', tagline: 'Say the feeling without forcing the sentence.', count: 12 },
  { slug: 'zodiac', name: 'Zodiac', tagline: 'Symbols, signs, and a little personal mythology.', count: 10 },
  { slug: 'fictious', name: 'Fictious', tagline: 'Characters, surreal lines, and imagined worlds.', count: 8 },
  { slug: 'career', name: 'Career', tagline: 'Work identity without the corporate costume.', count: 9 },
  { slug: 'trends', name: 'Trends', tagline: 'Fresh visual language with a cleaner seasonal edge.', count: 7 },
];

export const occasions: Occasion[] = [
  { slug: 'gift-something-real', name: 'Gift Something Real', description: 'Meaningful gifting with optional wrap and note card.' },
  { slug: 'birthday-pick', name: 'Birthday Pick', description: 'Giftable tees with a stronger reveal moment.' },
  { slug: 'graduation-season', name: 'Graduation Season', description: 'Pieces that feel personal without feeling generic.' },
  { slug: 'eid-ramadan', name: 'Eid & Ramadan', description: 'Gift-led selection with a warm, celebratory tone.' },
  { slug: 'just-because', name: 'Just Because', description: 'Low-pressure gifts that still feel thought through.' },
];

export const artists: Artist[] = [
  { slug: 'nada-ibrahim', name: 'Nada Ibrahim', style: 'Fine line portraits with quiet tension and strong silhouettes.', count: 12 },
  { slug: 'karim-fathy', name: 'Karim Fathy', style: 'Graphic symbols, layered forms, and bolder contrast.', count: 9 },
  { slug: 'salma-hassan', name: 'Salma Hassan', style: 'Expressive faces, handwritten marks, and intimate detail.', count: 7 },
  { slug: 'mohamed-adel', name: 'Mohamed Adel', style: 'Minimal linework with a sharp editorial mood.', count: 6 },
];

export const products: Product[] = [
  {
    slug: 'the-weight-of-light',
    name: 'The Weight of Light',
    artist: 'Nada Ibrahim',
    artistSlug: 'nada-ibrahim',
    vibe: 'Fictious',
    vibeSlug: 'fictious',
    price: 799,
    giftReady: true,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80',
    identityLine: 'For the one who carries quiet intensity.',
  },
  {
    slug: 'midnight-compass',
    name: 'Midnight Compass',
    artist: 'Karim Fathy',
    artistSlug: 'karim-fathy',
    vibe: 'Career',
    vibeSlug: 'career',
    price: 799,
    image: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=900&q=80',
    identityLine: 'For the one who keeps moving without losing direction.',
  },
  {
    slug: 'speak-softly',
    name: 'Speak Softly',
    artist: 'Salma Hassan',
    artistSlug: 'salma-hassan',
    vibe: 'Emotions',
    vibeSlug: 'emotions',
    price: 849,
    giftReady: true,
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=900&q=80',
    identityLine: 'For the one who feels more than they explain.',
  },
  {
    slug: 'solar-echo',
    name: 'Solar Echo',
    artist: 'Mohamed Adel',
    artistSlug: 'mohamed-adel',
    vibe: 'Zodiac',
    vibeSlug: 'zodiac',
    price: 799,
    giftReady: true,
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=900&q=80',
    identityLine: 'For the one who reads signs everywhere.',
  },
  {
    slug: 'city-ritual',
    name: 'City Ritual',
    artist: 'Nada Ibrahim',
    artistSlug: 'nada-ibrahim',
    vibe: 'Trends',
    vibeSlug: 'trends',
    price: 829,
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=900&q=80',
    identityLine: 'For the one who turns routine into visual language.',
  },
  {
    slug: 'second-skin',
    name: 'Second Skin',
    artist: 'Karim Fathy',
    artistSlug: 'karim-fathy',
    vibe: 'Emotions',
    vibeSlug: 'emotions',
    price: 799,
    image: 'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?auto=format&fit=crop&w=900&q=80',
    identityLine: 'For the one who wants the shirt to speak first.',
  },
  {
    slug: 'lunar-margin',
    name: 'Lunar Margin',
    artist: 'Salma Hassan',
    artistSlug: 'salma-hassan',
    vibe: 'Zodiac',
    vibeSlug: 'zodiac',
    price: 819,
    giftReady: true,
    image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=900&q=80',
    identityLine: 'For the one who lives half in symbol, half in reality.',
  },
  {
    slug: 'office-after-hours',
    name: 'Office After Hours',
    artist: 'Mohamed Adel',
    artistSlug: 'mohamed-adel',
    vibe: 'Career',
    vibeSlug: 'career',
    price: 799,
    image: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80',
    identityLine: 'For the one who is more than the role they play at work.',
  },
];

export const featuredProducts = products.slice(0, 4);

export const cartItems = [
  { ...products[0], qty: 1, size: 'M' },
  { ...products[1], qty: 1, size: 'L' },
];

export const money = (value: number) => `${value.toLocaleString('en-US')} EGP`;
