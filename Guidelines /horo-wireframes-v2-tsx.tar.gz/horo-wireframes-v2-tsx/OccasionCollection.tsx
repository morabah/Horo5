import { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import { occasions, products } from './wireframe-data';
import { Container, FooterCta, PageShell, ProductCard, SectionTitle, TopNav } from './wireframe-kit';

const occasionMap: Record<string, string[]> = {
  'gift-something-real': ['the-weight-of-light', 'speak-softly', 'solar-echo', 'lunar-margin'],
  'birthday-pick': ['speak-softly', 'city-ritual', 'solar-echo'],
  'graduation-season': ['midnight-compass', 'office-after-hours', 'city-ritual'],
  'eid-ramadan': ['the-weight-of-light', 'solar-echo', 'lunar-margin'],
  'just-because': ['second-skin', 'speak-softly', 'city-ritual'],
};

export function OccasionCollection() {
  const { slug } = useParams();
  const activeOccasion = useMemo(() => occasions.find((item) => item.slug === slug) ?? occasions[0], [slug]);
  const filtered = useMemo(() => products.filter((item) => occasionMap[activeOccasion.slug]?.includes(item.slug)), [activeOccasion.slug]);

  return (
    <PageShell>
      <TopNav />
      <section className="py-10">
        <Container className="space-y-8">
          <nav className="text-sm text-neutral-500">
            <Link to="/" className="hover:text-neutral-900">Home</Link> / <Link to="/occasions" className="hover:text-neutral-900">Occasions</Link> / <span className="text-neutral-900">{activeOccasion.name}</span>
          </nav>

          <div className="grid gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
            <SectionTitle eyebrow="Occasion collection" title={activeOccasion.name} body={`${activeOccasion.description} Every item shown here should belong for a reason.`} />
            <div className="rounded-3xl border border-amber-200 bg-amber-50 p-5">
              <h3 className="text-lg font-semibold text-neutral-950">Optional gift module</h3>
              <p className="mt-2 text-sm leading-6 text-neutral-700">Add gift wrap + story card + note. Clear price delta: +90 EGP.</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 rounded-2xl border border-neutral-200 bg-white p-3">
            {['Size', 'Price', 'Vibe', 'Artist', 'Gift-ready only'].map((item) => (
              <button key={item} type="button" className="rounded-full border border-neutral-300 px-4 py-2 text-sm text-neutral-800">{item}</button>
            ))}
          </div>

          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((product) => <ProductCard key={product.slug} product={product} showGiftBadge />)}
          </div>

          <div className="rounded-3xl border border-neutral-200 bg-white p-5">
            <p className="mb-3 text-sm font-medium text-neutral-700">More occasions</p>
            <div className="flex flex-wrap gap-3">
              {occasions.filter((item) => item.slug !== activeOccasion.slug).map((item) => (
                <Link key={item.slug} to={`/occasions/${item.slug}`} className="rounded-full border border-neutral-300 px-4 py-2 text-sm text-neutral-800">{item.name}</Link>
              ))}
            </div>
          </div>
        </Container>
      </section>
      <FooterCta title="Want the stronger discovery path?" primaryLabel="Shop by Vibe" primaryTo="/vibes" secondaryLabel="Browse by Artist" secondaryTo="/artists" />
    </PageShell>
  );
}
