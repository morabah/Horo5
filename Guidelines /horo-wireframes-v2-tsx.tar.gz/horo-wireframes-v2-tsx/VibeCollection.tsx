import { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import { products, vibes } from './wireframe-data';
import { Container, FooterCta, PageShell, ProductCard, SectionTitle, TopNav, TrustList } from './wireframe-kit';

export function VibeCollection() {
  const { slug } = useParams();
  const activeVibe = useMemo(() => vibes.find((item) => item.slug === slug) ?? vibes[0], [slug]);
  const filtered = useMemo(() => products.filter((item) => item.vibeSlug === activeVibe.slug), [activeVibe.slug]);

  return (
    <PageShell>
      <TopNav />
      <section className="py-10">
        <Container className="space-y-8">
          <nav className="text-sm text-neutral-500">
            <Link to="/" className="hover:text-neutral-900">Home</Link> / <Link to="/vibes" className="hover:text-neutral-900">Vibes</Link> / <span className="text-neutral-900">{activeVibe.name}</span>
          </nav>

          <div className="grid gap-8 md:grid-cols-[1.05fr_0.95fr] md:items-end">
            <SectionTitle eyebrow="Vibe collection" title={activeVibe.name} body={`${activeVibe.tagline} ${filtered.length} designs currently shown.`} />
            <div className="rounded-3xl border border-neutral-200 bg-white p-4 text-sm text-neutral-700">
              Delivery note: Cairo 2–4 days · Outside Cairo 3–6 days
            </div>
          </div>

          <div className="sticky top-0 z-10 flex flex-wrap gap-3 rounded-2xl border border-neutral-200 bg-white/95 p-3 backdrop-blur">
            {['Filter', 'Sort', 'Size Guide', 'Delivery & Exchange'].map((item) => (
              <button key={item} type="button" className="rounded-full border border-neutral-300 px-4 py-2 text-sm text-neutral-800">{item}</button>
            ))}
          </div>

          <div className="grid gap-6 xl:grid-cols-[1fr_280px] xl:items-start">
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((product) => <ProductCard key={product.slug} product={product} />)}
            </div>
            <aside className="space-y-4 xl:sticky xl:top-20">
              <TrustList items={['220 GSM cotton', 'Free size exchange', 'Delivery estimate shown before checkout', 'COD available']} />
            </aside>
          </div>

          <div className="flex flex-wrap gap-3 rounded-3xl border border-neutral-200 bg-white p-5">
            <span className="text-sm font-medium text-neutral-700">Explore other vibes:</span>
            {vibes.filter((item) => item.slug !== activeVibe.slug).map((item) => (
              <Link key={item.slug} to={`/vibes/${item.slug}`} className="rounded-full border border-neutral-300 px-4 py-2 text-sm text-neutral-800">{item.name}</Link>
            ))}
          </div>
        </Container>
      </section>
      <FooterCta title="Need a more gift-led route?" primaryLabel="Shop by Occasion" primaryTo="/occasions" secondaryLabel="Browse by Artist" secondaryTo="/artists" />
    </PageShell>
  );
}
