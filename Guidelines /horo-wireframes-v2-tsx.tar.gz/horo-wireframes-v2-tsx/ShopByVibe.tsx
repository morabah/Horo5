import { Link } from 'react-router-dom';
import { vibes } from './wireframe-data';
import { Container, FooterCta, PageShell, SectionTitle, TopNav, VibeCard } from './wireframe-kit';

export function ShopByVibe() {
  return (
    <PageShell>
      <TopNav />
      <section className="py-14 sm:py-16">
        <Container className="space-y-8">
          <SectionTitle eyebrow="Main collection gateway" title="Which vibe is yours?" body="Start with the feeling, then narrow to the design. Keep this page fast to scan and strict about what each route promises." />
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
            {vibes.map((vibe) => <VibeCard key={vibe.slug} vibe={vibe} />)}
          </div>
          <div className="rounded-3xl border border-neutral-200 bg-white p-5 text-sm leading-7 text-neutral-700">
            Need a gift? <Link to="/occasions" className="font-medium text-neutral-950">Shop by Occasion</Link>
            <span className="mx-2 text-neutral-300">•</span>
            Love the illustrator? <Link to="/artists" className="font-medium text-neutral-950">Browse by Artist</Link>
          </div>
        </Container>
      </section>
      <FooterCta title="Prefer a more directed route?" primaryLabel="Shop by Occasion" primaryTo="/occasions" secondaryLabel="Browse by Artist" secondaryTo="/artists" />
    </PageShell>
  );
}
