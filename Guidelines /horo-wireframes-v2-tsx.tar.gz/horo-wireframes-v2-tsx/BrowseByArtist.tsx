import { Link } from 'react-router-dom';
import { artists } from './wireframe-data';
import { ArtistCard, Container, FooterCta, PageShell, SectionTitle, TopNav, TrustList } from './wireframe-kit';

export function BrowseByArtist() {
  return (
    <PageShell>
      <TopNav />
      <section className="py-14 sm:py-16">
        <Container className="space-y-8">
          <SectionTitle eyebrow="Secondary discovery path" title="Browse by Artist" body="See the hands behind the linework. Keep the focus on visual language and product, not celebrity-style storytelling." />
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
            {artists.map((artist) => <ArtistCard key={artist.slug} artist={artist} />)}
          </div>
          <TrustList items={['Real illustration', 'Licensed artwork', 'Printed for wear, not framed display']} />
          <div className="rounded-3xl border border-neutral-200 bg-white p-5 text-sm leading-7 text-neutral-700">
            <Link to="/vibes" className="font-medium text-neutral-950">Shop by Vibe</Link>
            <span className="mx-2 text-neutral-300">•</span>
            <Link to="/occasions" className="font-medium text-neutral-950">Shop by Occasion</Link>
          </div>
        </Container>
      </section>
      <FooterCta title="Ready to move from artist to product?" primaryLabel="Shop by Vibe" primaryTo="/vibes" secondaryLabel="Shop by Occasion" secondaryTo="/occasions" />
    </PageShell>
  );
}
