import { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import { artists, products } from './wireframe-data';
import { Container, FooterCta, PageShell, ProductCard, SectionTitle, TopNav } from './wireframe-kit';

export function ArtistProfile() {
  const { slug } = useParams();
  const artist = useMemo(() => artists.find((item) => item.slug === slug) ?? artists[0], [slug]);
  const portfolio = useMemo(() => products.filter((item) => item.artistSlug === artist.slug), [artist.slug]);

  return (
    <PageShell>
      <TopNav />
      <section className="py-10">
        <Container className="space-y-8">
          <nav className="text-sm text-neutral-500">
            <Link to="/" className="hover:text-neutral-900">Home</Link> / <Link to="/artists" className="hover:text-neutral-900">Artists</Link> / <span className="text-neutral-900">{artist.name}</span>
          </nav>

          <div className="grid gap-8 lg:grid-cols-[0.7fr_1.3fr] lg:items-end">
            <div className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm">
              <div className="mb-5 h-24 w-24 rounded-full bg-gradient-to-br from-neutral-200 to-neutral-300" />
              <p className="text-xs uppercase tracking-[0.2em] text-neutral-500">Illustrated by</p>
              <h1 className="mt-2 text-3xl font-semibold tracking-tight text-neutral-950">{artist.name}</h1>
              <p className="mt-3 text-sm leading-6 text-neutral-600">{artist.style}</p>
              <p className="mt-4 text-sm text-neutral-500">{artist.count} designs for HORO</p>
            </div>
            <div className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm">
              <SectionTitle eyebrow="Short process statement" title="Approach" body="Keep the bio tight. Move product higher. This page should prove legitimacy, then lead into the portfolio fast." />
              <p className="mt-4 text-sm leading-7 text-neutral-700">
                The work begins with line, mood, and a symbol that still survives translation onto fabric. The goal is not to write a long biography. The goal is to help the customer understand the visual language.
              </p>
            </div>
          </div>

          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {portfolio.map((product) => <ProductCard key={product.slug} product={product} />)}
          </div>

          <div className="rounded-3xl border border-neutral-200 bg-white p-5">
            <p className="mb-3 text-sm font-medium text-neutral-700">Other artists</p>
            <div className="flex flex-wrap gap-3">
              {artists.filter((item) => item.slug !== artist.slug).map((item) => (
                <Link key={item.slug} to={`/artists/${item.slug}`} className="rounded-full border border-neutral-300 px-4 py-2 text-sm text-neutral-800">{item.name}</Link>
              ))}
            </div>
          </div>
        </Container>
      </section>
      <FooterCta title="Back to broader product discovery" primaryLabel="Shop by Vibe" primaryTo="/vibes" secondaryLabel="Shop by Occasion" secondaryTo="/occasions" />
    </PageShell>
  );
}
