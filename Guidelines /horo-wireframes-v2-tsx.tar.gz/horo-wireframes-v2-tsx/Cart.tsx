import { Link } from 'react-router-dom';
import { cartItems, money } from './wireframe-data';
import { Container, FooterCta, PageShell, SectionTitle, SummaryRow, TopNav } from './wireframe-kit';

export function Cart() {
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);
  const cairoEstimate = 60;
  const outsideEstimate = 90;
  const freeShippingThreshold = 1800;

  return (
    <PageShell>
      <TopNav />
      <section className="py-10">
        <Container className="grid gap-8 xl:grid-cols-[1.2fr_0.8fr] xl:items-start">
          <div className="space-y-6">
            <SectionTitle eyebrow="Cart" title={`Your Cart · ${cartItems.length} items`} body="This page should remove surprise before checkout, not delay clarity until the last step." />

            <div className="space-y-4">
              {cartItems.map((item) => (
                <div key={`${item.slug}-${item.size}`} className="grid gap-4 rounded-[2rem] border border-neutral-200 bg-white p-5 shadow-sm sm:grid-cols-[120px_1fr]">
                  <img src={item.image} alt={item.name} className="aspect-square w-full rounded-[1.25rem] object-cover" />
                  <div className="space-y-3">
                    <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                      <div>
                        <h3 className="text-lg font-semibold text-neutral-950">{item.name}</h3>
                        <p className="text-sm text-neutral-600">Illustrated by {item.artist}</p>
                      </div>
                      <p className="text-sm font-medium text-neutral-950">{money(item.price)}</p>
                    </div>
                    <div className="flex flex-wrap items-center gap-3 text-sm text-neutral-700">
                      <span>Size {item.size}</span>
                      <span className="text-neutral-300">•</span>
                      <div className="inline-flex items-center rounded-full border border-neutral-300">
                        <button type="button" className="px-3 py-1.5">−</button>
                        <span className="px-3 py-1.5">{item.qty}</span>
                        <button type="button" className="px-3 py-1.5">+</button>
                      </div>
                      <button type="button" className="text-neutral-500 underline">Remove</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-[2rem] border border-amber-200 bg-amber-50 p-6">
              <h3 className="text-lg font-semibold text-neutral-950">Add a 3rd and save</h3>
              <p className="mt-2 text-sm leading-6 text-neutral-700">Keep only one upsell module. Make it relevant to the number of items already in the basket.</p>
            </div>
          </div>

          <aside className="space-y-5 xl:sticky xl:top-20">
            <div className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm">
              <h2 className="text-lg font-semibold text-neutral-950">Order summary</h2>
              <div className="mt-4 divide-y divide-neutral-200">
                <SummaryRow label="Subtotal" value={money(subtotal)} />
                <div className="py-3 text-sm text-neutral-700">
                  <p className="font-medium text-neutral-950">Estimated shipping</p>
                  <p className="mt-2">Cairo from {money(cairoEstimate)}</p>
                  <p>Outside Cairo from {money(outsideEstimate)}</p>
                  <p className="mt-2 text-neutral-500">Free shipping above {money(freeShippingThreshold)}</p>
                </div>
                <SummaryRow label="Estimated total" value={money(subtotal + cairoEstimate)} strong />
              </div>
              <div className="mt-5 space-y-3">
                <Link to="/checkout" className="block rounded-full bg-neutral-950 px-5 py-3 text-center text-sm font-medium text-white">Proceed to Checkout</Link>
                <Link to="/vibes" className="block rounded-full border border-neutral-300 px-5 py-3 text-center text-sm font-medium text-neutral-900">Continue Shopping</Link>
              </div>
            </div>

            <div className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm text-sm leading-7 text-neutral-700">
              <p>COD available</p>
              <p>Free size exchange within 14 days</p>
              <p>Delivery estimate shown before payment</p>
              <p>Need help? WhatsApp support entry goes here</p>
            </div>
          </aside>
        </Container>
      </section>
      <FooterCta title="Still comparing designs?" primaryLabel="Back to Vibes" primaryTo="/vibes" secondaryLabel="Shop by Occasion" secondaryTo="/occasions" />
    </PageShell>
  );
}
