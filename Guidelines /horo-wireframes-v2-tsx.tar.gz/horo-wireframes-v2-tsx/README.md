# HORO v2 wireframes in TSX

These files convert the v2 markdown wireframes into lightweight React + TypeScript page components.

What is included:
- updated page hierarchy based on the latest UX review
- product-first homepage flow
- stronger cart and checkout trust treatment
- new `OrderConfirmation.tsx` and `SearchResults.tsx`
- shared demo data and reusable wireframe components

Assumptions:
- React Router is available
- Tailwind CSS is available
- these are structural wireframes, so demo content is static and should be connected to your real data layer later

Files:
- `wireframe-data.ts`
- `wireframe-kit.tsx`
- `Home.tsx`
- `ShopByVibe.tsx`
- `VibeCollection.tsx`
- `ShopByOccasion.tsx`
- `OccasionCollection.tsx`
- `BrowseByArtist.tsx`
- `ArtistProfile.tsx`
- `ProductDetail.tsx`
- `Cart.tsx`
- `Checkout.tsx`
- `OrderConfirmation.tsx`
- `SearchResults.tsx`
