import { Link } from 'react-router-dom';
import { cartItems, money } from './wireframe-data';
import { Container, FooterCta, PageShell, SummaryRow, TopNav } from './wireframe-kit';

export function OrderConfirmation() {
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);
  const shipping = 60;
  const total = subtotal + shipping;

  return (
    <PageShell>
      <TopNav />
      <section className="py-14 sm:py-16">
        <Container className="space-y-8">
          <div className="rounded-[2rem] border border-emerald-200 bg-emerald-50 p-6">
            <p className="text-xs font-medium uppercase tracking-[0.24em] text-emerald-700">Order confirmed</p>
            <h1 className="mt-2 text-3xl font-semibold tracking-tight text-neutral-950">You completed this design</h1>
            <p className="mt-3 text-sm leading-7 text-neutral-700">Order #HR-240318 confirmed. WhatsApp confirmation is on the way.</p>
          </div>

          <div className="grid gap-8 xl:grid-cols-[1fr_0.9fr]">
            <div className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm">
              <h2 className="text-lg font-semibold text-neutral-950">What happens next</h2>
              <div className="mt-5 grid gap-4 md:grid-cols-4">
                {['Confirmation', 'Preparation', 'Shipping', 'Delivery'].map((step, index) => (
                  <div key={step} className="rounded-2xl bg-stone-50 p-4 text-sm text-neutral-700">
                    <p className="font-semibold text-neutral-950">{index + 1}. {step}</p>
                  </div>
                ))}
              </div>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link to="/track-order" className="rounded-full bg-neutral-950 px-5 py-3 text-sm font-medium text-white">Track Order</Link>
                <a href="https://wa.me/201000000000" className="rounded-full border border-neutral-300 px-5 py-3 text-sm font-medium text-neutral-900">Need help? WhatsApp</a>
              </div>
            </div>

            <aside className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm">
              <h2 className="text-lg font-semibold text-neutral-950">Order summary</h2>
              <div className="mt-4 space-y-4">
                {cartItems.map((item) => (
                  <div key={`${item.slug}-${item.size}`} className="flex gap-3">
                    <img src={item.image} alt={item.name} className="h-16 w-16 rounded-2xl object-cover" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-neutral-950">{item.name}</p>
                      <p className="text-sm text-neutral-600">Size {item.size} · Qty {item.qty}</p>
                    </div>
                    <p className="text-sm text-neutral-950">{money(item.price)}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4 divide-y divide-neutral-200">
                <SummaryRow label="Shipping" value={money(shipping)} />
                <SummaryRow label="Payment method" value="Cash on delivery" />
                <SummaryRow label="Address" value="Nasr City, Cairo" />
                <SummaryRow label="Total" value={money(total)} strong />
              </div>
            </aside>
          </div>

          <div className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm text-sm leading-7 text-neutral-700">
            Tag us in your first wear. This page should lower COD drop-off risk by increasing certainty, not end as a dead screen.
          </div>
        </Container>
      </section>
      <FooterCta title="Keep browsing while you wait" primaryLabel="Back to Vibes" primaryTo="/vibes" secondaryLabel="Browse new arrivals" secondaryTo="/search?q=new" />
    </PageShell>
  );
}
