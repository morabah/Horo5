import { Link } from 'react-router-dom';
import { artists, featuredProducts, vibes } from './wireframe-data';
import { Container, FooterCta, PageShell, ProductCard, ProofPill, SectionTitle, TopNav } from './wireframe-kit';

export function Home() {
  return (
    <PageShell>
      <TopNav />

      <section className="bg-neutral-950 text-white">
        <Container className="grid gap-10 py-12 md:grid-cols-[1.05fr_0.95fr] md:items-center md:py-20">
          <div className="order-2 max-w-xl space-y-6 md:order-1">
            <p className="text-xs font-medium uppercase tracking-[0.28em] text-amber-300">Premium wearable art</p>
            <h1 className="text-4xl font-semibold tracking-tight sm:text-5xl">Wear What You Mean</h1>
            <p className="text-base leading-7 text-neutral-300 sm:text-lg">
              Artist-made premium tees on heavy cotton, built for everyday self-expression.
            </p>
            <div className="space-y-3">
              <p className="text-sm uppercase tracking-[0.2em] text-neutral-400">From 799 EGP</p>
              <div className="flex flex-wrap gap-3">
                <Link to="/vibes" className="rounded-full bg-white px-5 py-3 text-sm font-medium text-neutral-950">Shop by Vibe</Link>
                <Link to="/vibes/fictious" className="rounded-full border border-white/20 px-5 py-3 text-sm font-medium text-white">View New Drop</Link>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              <ProofPill>COD</ProofPill>
              <ProofPill>Free size exchange</ProofPill>
              <ProofPill>220 GSM cotton</ProofPill>
            </div>
          </div>
          <div className="order-1 overflow-hidden rounded-[2rem] border border-white/10 bg-neutral-900 shadow-2xl md:order-2">
            <img
              src="https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1400&q=80"
              alt="HORO hero fashion shot"
              className="aspect-[4/5] h-full w-full object-cover"
            />
          </div>
        </Container>
      </section>

      <section className="border-b border-neutral-200 bg-white py-4">
        <Container className="flex flex-wrap gap-3">
          <ProofPill>220 GSM Cotton</ProofPill>
          <ProofPill>Licensed Artwork</ProofPill>
          <ProofPill>Cairo-made photography</ProofPill>
          <ProofPill>COD available</ProofPill>
        </Container>
      </section>

      <section className="py-14 sm:py-16">
        <Container className="space-y-8">
          <SectionTitle eyebrow="Start here" title="Start with the feeling" body="Choose the mood first, then narrow to the design. This stays the main browse path across the whole site." />
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-5">
            {vibes.map((vibe) => (
              <Link key={vibe.slug} to={`/vibes/${vibe.slug}`} className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-md">
                <div className="mb-4 aspect-[4/5] rounded-2xl bg-gradient-to-br from-neutral-900 via-neutral-700 to-neutral-500" />
                <h3 className="text-lg font-semibold text-neutral-950">{vibe.name}</h3>
                <p className="mt-2 text-sm leading-6 text-neutral-600">{vibe.tagline}</p>
                <div className="mt-4 flex items-center justify-between text-sm">
                  <span className="text-neutral-500">{vibe.count} designs</span>
                  <span className="font-medium text-neutral-950">Explore →</span>
                </div>
              </Link>
            ))}
          </div>
        </Container>
      </section>

      <section className="border-t border-neutral-200 bg-white py-14 sm:py-16">
        <Container className="space-y-8">
          <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
            <SectionTitle eyebrow="New drop" title="Just Dropped" body="Move product discovery earlier. Do not make visitors read a manifesto before they see shoppable pieces." />
            <Link to="/search?q=new" className="text-sm font-medium text-neutral-950">View all designs →</Link>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
            {featuredProducts.map((product) => <ProductCard key={product.slug} product={product} />)}
          </div>
        </Container>
      </section>

      <section className="py-14 sm:py-16">
        <Container className="space-y-8">
          <SectionTitle eyebrow="Why HORO" title="Why HORO is worth buying" body="Show real reasons to trust the product, not only the brand mood." />
          <div className="grid gap-5 md:grid-cols-3">
            {[
              ['Heavy cotton that feels premium', '220 GSM fabric with a fuller hand feel and more structure on-body.'],
              ['Artist-made designs', 'Illustration-led pieces, not generic print-shop output or random clipart.'],
              ['Designed for gifting and self-expression', 'A stronger story for personal wear and for thoughtful gifting.'],
            ].map(([title, body]) => (
              <div key={title} className="rounded-3xl border border-neutral-200 bg-white p-6 shadow-sm">
                <h3 className="text-lg font-semibold text-neutral-950">{title}</h3>
                <p className="mt-3 text-sm leading-6 text-neutral-600">{body}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <section className="border-y border-neutral-200 bg-white py-14 sm:py-16">
        <Container className="grid gap-5 md:grid-cols-4">
          {[
            'Fit note: relaxed unisex silhouette',
            'Preview the size guide before entering PDP',
            'Delivery: Cairo 2–4 days, outside Cairo 3–6 days',
            'Free size exchange within 14 days',
          ].map((item) => (
            <div key={item} className="rounded-2xl border border-neutral-200 px-4 py-4 text-sm text-neutral-700">{item}</div>
          ))}
        </Container>
      </section>

      <section className="py-14 sm:py-16">
        <Container className="grid gap-8 md:grid-cols-[0.95fr_1.05fr] md:items-center">
          <div className="overflow-hidden rounded-[2rem] border border-neutral-200 bg-white shadow-sm">
            <div className="grid grid-cols-2 gap-2 p-2">
              <img src="https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80" alt="Artist process board" className="aspect-square w-full rounded-[1.25rem] object-cover" />
              <img src="https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=900&q=80" alt="Screen detail" className="aspect-square w-full rounded-[1.25rem] object-cover" />
              <div className="col-span-2 rounded-[1.25rem] bg-neutral-100 p-5 text-sm leading-6 text-neutral-600">
                One artist feature is enough on the homepage. The goal is to prove craft and originality, not to let biography overtake the storefront.
              </div>
            </div>
          </div>
          <div className="max-w-xl space-y-5">
            <SectionTitle eyebrow="Behind the work" title={`Selected process — ${artists[0].name}`} body="Keep the artist visible, but supporting. Product comes first, then proof, then process." />
            <p className="text-sm leading-7 text-neutral-600">
              Fine line portrait work, controlled contrast, and symbols that still read clearly when printed for wear. This block should stay short and direct.
            </p>
            <Link to="/artists" className="inline-flex rounded-full border border-neutral-300 px-5 py-3 text-sm font-medium text-neutral-900">Browse by Artist</Link>
          </div>
        </Container>
      </section>

      <section className="border-t border-neutral-200 bg-white py-14 sm:py-16">
        <Container className="space-y-8">
          <SectionTitle eyebrow="Proof" title="What shoppers notice" body="Make reviews useful. They should speak about quality, fit, gifting, and whether expectations matched reality." />
          <div className="grid gap-5 md:grid-cols-3">
            {[
              'The cotton feels noticeably heavier than most graphic tees. The print did not feel cheap at all.',
              'I bought it as a gift and the note card made it feel more thoughtful, not last-minute.',
              'Fit was easy to judge, and free exchange made the first order less stressful.',
            ].map((quote, idx) => (
              <div key={idx} className="rounded-3xl border border-neutral-200 bg-stone-50 p-6">
                <p className="text-sm leading-7 text-neutral-700">“{quote}”</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <FooterCta title="Find the design that feels like yours" primaryLabel="Shop by Vibe" primaryTo="/vibes" secondaryLabel="Browse by Artist" secondaryTo="/artists" />
    </PageShell>
  );
}
