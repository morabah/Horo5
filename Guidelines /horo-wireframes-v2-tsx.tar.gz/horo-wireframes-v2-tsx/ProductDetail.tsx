import { Link, useParams } from 'react-router-dom';
import { useMemo, useState } from 'react';
import { products } from './wireframe-data';
import { Container, FooterCta, PageShell, ProductCard, SectionTitle, SummaryRow, TopNav } from './wireframe-kit';
import { money } from './wireframe-data';

const galleryFallback = [
  'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=1200&q=80',
];

export function ProductDetail() {
  const { slug } = useParams();
  const product = useMemo(() => products.find((item) => item.slug === slug) ?? products[0], [slug]);
  const related = useMemo(() => products.filter((item) => item.vibeSlug === product.vibeSlug && item.slug !== product.slug).slice(0, 4), [product.slug, product.vibeSlug]);
  const [activeImage, setActiveImage] = useState(galleryFallback[0]);

  return (
    <PageShell>
      <TopNav />
      <section className="py-10">
        <Container className="space-y-8">
          <nav className="text-sm text-neutral-500">
            <Link to="/" className="hover:text-neutral-900">Home</Link> / <Link to="/vibes" className="hover:text-neutral-900">Vibes</Link> / <Link to={`/vibes/${product.vibeSlug}`} className="hover:text-neutral-900">{product.vibe}</Link> / <span className="text-neutral-900">{product.name}</span>
          </nav>

          <div className="grid gap-8 xl:grid-cols-[1.1fr_0.9fr] xl:items-start">
            <div className="space-y-4">
              <div className="overflow-hidden rounded-[2rem] border border-neutral-200 bg-white shadow-sm">
                <img src={activeImage} alt={product.name} className="aspect-[4/5] h-full w-full object-cover" />
              </div>
              <div className="grid grid-cols-5 gap-3">
                {galleryFallback.map((image, index) => (
                  <button key={index} type="button" onClick={() => setActiveImage(image)} className={`overflow-hidden rounded-2xl border ${activeImage === image ? 'border-neutral-900' : 'border-neutral-200'} bg-white`}>
                    <img src={image} alt={`Preview ${index + 1}`} className="aspect-square h-full w-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-6 rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm xl:sticky xl:top-20">
              <p className="text-xs uppercase tracking-[0.22em] text-neutral-500">{product.vibe}</p>
              <h1 className="text-3xl font-semibold tracking-tight text-neutral-950">{product.name}</h1>
              <p className="text-sm text-neutral-600">Illustrated by <Link to={`/artists/${product.artistSlug}`} className="font-medium text-neutral-900">{product.artist}</Link></p>
              <p className="text-sm leading-7 text-neutral-700">{product.identityLine}</p>
              <p className="text-xl font-semibold text-neutral-950">{money(product.price)}</p>

              <div>
                <div className="mb-3 flex items-center justify-between text-sm">
                  <span className="font-medium text-neutral-900">Select size</span>
                  <button type="button" className="text-neutral-600 underline">Size guide</button>
                </div>
                <div className="grid grid-cols-4 gap-3">
                  {['S', 'M', 'L', 'XL'].map((size) => (
                    <button key={size} type="button" className="rounded-2xl border border-neutral-300 px-4 py-3 text-sm font-medium text-neutral-800">{size}</button>
                  ))}
                </div>
              </div>

              <button type="button" className="w-full rounded-full bg-neutral-950 px-5 py-3 text-sm font-medium text-white">Add to Cart</button>

              <div className="rounded-2xl bg-stone-50 p-4 text-sm leading-7 text-neutral-700">
                Ships in 2–4 days · Free size exchange · COD available
              </div>
            </div>
          </div>

          <div className="grid gap-5 md:grid-cols-3">
            <div className="rounded-3xl border border-neutral-200 bg-white p-5 text-sm leading-7 text-neutral-700">
              <p className="font-semibold text-neutral-950">Fit</p>
              <p className="mt-2">Relaxed oversized fit. Model is 178 cm wearing size M.</p>
            </div>
            <div className="rounded-3xl border border-neutral-200 bg-white p-5 text-sm leading-7 text-neutral-700">
              <p className="font-semibold text-neutral-950">Delivery</p>
              <p className="mt-2">Cairo 2–4 days · Outside Cairo 3–6 days.</p>
            </div>
            <div className="rounded-3xl border border-neutral-200 bg-white p-5 text-sm leading-7 text-neutral-700">
              <p className="font-semibold text-neutral-950">Exchange & return</p>
              <p className="mt-2">Exchange available within 14 days. Return policy link should remain visible.</p>
            </div>
          </div>

          <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
            <div className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm">
              <SectionTitle eyebrow="Details" title="Product details" body="Keep story present, but never bury the purchase decision under it." />
              <div className="mt-5 divide-y divide-neutral-200">
                <SummaryRow label="Fabric" value="220 GSM cotton" />
                <SummaryRow label="Print" value="High-definition front artwork" />
                <SummaryRow label="Care" value="Cold wash inside out" />
                <SummaryRow label="Fit" value="Relaxed unisex silhouette" />
              </div>
              <p className="mt-5 text-sm leading-7 text-neutral-700">
                Design story: a portrait-led piece meant to carry mood without forcing a loud statement. The print detail should remain sharp at close range and read clearly from distance.
              </p>
            </div>

            <div className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm">
              <SectionTitle eyebrow="Reviews / UGC" title="What buyers say" body="Reviews should help on quality, fit, and whether gifting expectations were met." />
              <div className="mt-5 space-y-4">
                {[
                  'True to the fit note. The fabric had much more structure than I expected.',
                  'Bought it as a gift and the whole thing felt more thoughtful than standard online tees.',
                  'The close-up print matched the product photos, which made the price feel justified.',
                ].map((quote, idx) => (
                  <div key={idx} className="rounded-2xl bg-stone-50 p-4 text-sm leading-7 text-neutral-700">“{quote}”</div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <SectionTitle eyebrow="More from this vibe" title="Recommendations" />
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
              {related.map((item) => <ProductCard key={item.slug} product={item} />)}
            </div>
          </div>
        </Container>
      </section>
      <FooterCta title="Need a broader browse route?" primaryLabel="Back to Vibes" primaryTo="/vibes" secondaryLabel="Browse by Artist" secondaryTo="/artists" />
    </PageShell>
  );
}
