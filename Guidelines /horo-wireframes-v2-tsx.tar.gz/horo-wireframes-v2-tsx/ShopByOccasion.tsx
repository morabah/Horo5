import { Link } from 'react-router-dom';
import { occasions } from './wireframe-data';
import { Container, FooterCta, PageShell, SectionTitle, TopNav } from './wireframe-kit';

export function ShopByOccasion() {
  return (
    <PageShell>
      <TopNav />
      <section className="py-14 sm:py-16">
        <Container className="space-y-8">
          <SectionTitle eyebrow="Secondary browse path" title="Shop by Occasion" body="Find a design for the moment, not just the category. Keep this page useful, honest, and lighter than the main vibe route." />
          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-5">
            {occasions.map((occasion) => (
              <Link key={occasion.slug} to={`/occasions/${occasion.slug}`} className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-md">
                <div className="mb-4 aspect-[4/5] rounded-2xl bg-gradient-to-br from-amber-100 via-neutral-100 to-neutral-200" />
                <h3 className="text-lg font-semibold text-neutral-950">{occasion.name}</h3>
                <p className="mt-2 text-sm leading-6 text-neutral-600">{occasion.description}</p>
                <span className="mt-4 inline-flex text-sm font-medium text-neutral-950">Explore →</span>
              </Link>
            ))}
          </div>

          <div className="rounded-3xl border border-neutral-200 bg-white p-6">
            <h3 className="text-lg font-semibold text-neutral-950">What makes a HORO gift different?</h3>
            <ul className="mt-4 space-y-3 text-sm text-neutral-700">
              <li>• Story-led design instead of generic gifting.</li>
              <li>• Optional gift wrap and meaningful note card.</li>
              <li>• Product-first gifting, not empty bundle language.</li>
            </ul>
          </div>

          <div className="rounded-3xl border border-neutral-200 bg-white p-5 text-sm leading-7 text-neutral-700">
            Prefer to browse by feeling? <Link to="/vibes" className="font-medium text-neutral-950">Shop by Vibe</Link>
            <span className="mx-2 text-neutral-300">•</span>
            Want to see the illustrators? <Link to="/artists" className="font-medium text-neutral-950">Browse by Artist</Link>
          </div>
        </Container>
      </section>
      <FooterCta title="Start with the stronger browse path" primaryLabel="Shop by Vibe" primaryTo="/vibes" secondaryLabel="Browse by Artist" secondaryTo="/artists" />
    </PageShell>
  );
}
