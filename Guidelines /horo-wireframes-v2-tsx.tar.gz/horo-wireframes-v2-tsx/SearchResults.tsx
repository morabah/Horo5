import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { artists, products, vibes } from './wireframe-data';
import { Container, FooterCta, PageShell, ProductCard, SectionTitle, TopNav } from './wireframe-kit';

export function SearchResults() {
  const [params] = useSearchParams();
  const query = (params.get('q') ?? 'light').toLowerCase();
  const [tab, setTab] = useState<'designs' | 'vibes' | 'artists'>('designs');

  const matchingProducts = useMemo(
    () => products.filter((item) => [item.name, item.artist, item.vibe, item.identityLine].join(' ').toLowerCase().includes(query)),
    [query],
  );
  const matchingVibes = useMemo(() => vibes.filter((item) => [item.name, item.tagline].join(' ').toLowerCase().includes(query)), [query]);
  const matchingArtists = useMemo(() => artists.filter((item) => [item.name, item.style].join(' ').toLowerCase().includes(query)), [query]);

  return (
    <PageShell>
      <TopNav />
      <section className="py-10">
        <Container className="space-y-8">
          <SectionTitle eyebrow="Search" title={`Results for “${query}”`} body="Keep search product-first when intent is unclear, then offer strong recovery paths." />

          <div className="rounded-[2rem] border border-neutral-200 bg-white p-4 shadow-sm">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <input defaultValue={query} className="w-full rounded-2xl border border-neutral-300 px-4 py-3 text-sm text-neutral-900 md:max-w-lg" placeholder="Search designs, vibes, artists" />
              <div className="flex flex-wrap gap-2">
                {(['designs', 'vibes', 'artists'] as const).map((item) => (
                  <button key={item} type="button" onClick={() => setTab(item)} className={`rounded-full px-4 py-2 text-sm ${tab === item ? 'bg-neutral-950 text-white' : 'border border-neutral-300 text-neutral-700'}`}>
                    {item[0].toUpperCase() + item.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {tab === 'designs' ? (
            <>
              <div className="flex flex-wrap gap-3 rounded-2xl border border-neutral-200 bg-white p-3">
                {['Size', 'Vibe', 'Artist', 'Price'].map((item) => (
                  <button key={item} type="button" className="rounded-full border border-neutral-300 px-4 py-2 text-sm text-neutral-800">{item}</button>
                ))}
              </div>
              {matchingProducts.length > 0 ? (
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {matchingProducts.map((product) => <ProductCard key={product.slug} product={product} />)}
                </div>
              ) : (
                <EmptyState query={query} />
              )}
            </>
          ) : null}

          {tab === 'vibes' ? (
            matchingVibes.length > 0 ? (
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
                {matchingVibes.map((vibe) => (
                  <Link key={vibe.slug} to={`/vibes/${vibe.slug}`} className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm">
                    <h3 className="text-lg font-semibold text-neutral-950">{vibe.name}</h3>
                    <p className="mt-2 text-sm leading-6 text-neutral-600">{vibe.tagline}</p>
                  </Link>
                ))}
              </div>
            ) : (
              <EmptyState query={query} />
            )
          ) : null}

          {tab === 'artists' ? (
            matchingArtists.length > 0 ? (
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
                {matchingArtists.map((artist) => (
                  <Link key={artist.slug} to={`/artists/${artist.slug}`} className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm">
                    <p className="text-xs uppercase tracking-[0.2em] text-neutral-500">Illustrated by</p>
                    <h3 className="mt-2 text-lg font-semibold text-neutral-950">{artist.name}</h3>
                    <p className="mt-2 text-sm leading-6 text-neutral-600">{artist.style}</p>
                  </Link>
                ))}
              </div>
            ) : (
              <EmptyState query={query} />
            )
          ) : null}

          <div className="rounded-[2rem] border border-neutral-200 bg-white p-5 text-sm leading-7 text-neutral-700">
            Helpful recovery: Did you mean a related vibe, artist, or new drop? Search should always offer a path forward.
          </div>
        </Container>
      </section>
      <FooterCta title="Need a clearer starting point?" primaryLabel="Shop by Vibe" primaryTo="/vibes" secondaryLabel="Browse new arrivals" secondaryTo="/search?q=new" />
    </PageShell>
  );
}

function EmptyState({ query }: { query: string }) {
  return (
    <div className="rounded-[2rem] border border-neutral-200 bg-white p-8 text-center shadow-sm">
      <h3 className="text-xl font-semibold text-neutral-950">No results for “{query}”</h3>
      <p className="mt-3 text-sm text-neutral-600">Search should never end in a dead-end screen.</p>
      <div className="mt-5 flex flex-wrap justify-center gap-3">
        <Link to="/vibes" className="rounded-full bg-neutral-950 px-5 py-3 text-sm font-medium text-white">Shop by Vibe</Link>
        <Link to="/search?q=new" className="rounded-full border border-neutral-300 px-5 py-3 text-sm font-medium text-neutral-900">Browse new arrivals</Link>
      </div>
    </div>
  );
}
