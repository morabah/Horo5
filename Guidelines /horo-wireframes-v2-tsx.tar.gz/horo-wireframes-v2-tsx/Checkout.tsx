import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { cartItems, money } from './wireframe-data';
import { Container, PageShell, SummaryRow, TopNav } from './wireframe-kit';

const steps = ['Information', 'Shipping', 'Payment'] as const;

export function Checkout() {
  const [step, setStep] = useState(0);
  const [shippingCost, setShippingCost] = useState(60);
  const subtotal = useMemo(() => cartItems.reduce((sum, item) => sum + item.price * item.qty, 0), []);
  const total = subtotal + shippingCost;

  return (
    <PageShell>
      <TopNav />
      <section className="py-10">
        <Container className="space-y-6">
          <Link to="/cart" className="text-sm text-neutral-600 hover:text-neutral-900">← Back to cart</Link>

          <div className="rounded-[2rem] border border-neutral-200 bg-white p-4 shadow-sm">
            <div className="flex flex-wrap items-center gap-3">
              {steps.map((label, index) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => setStep(index)}
                  className={`rounded-full px-4 py-2 text-sm ${step === index ? 'bg-neutral-950 text-white' : 'border border-neutral-300 text-neutral-700'}`}
                >
                  {index + 1}. {label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-8 xl:grid-cols-[1fr_360px] xl:items-start">
            <div className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm">
              {step === 0 ? (
                <div className="space-y-5">
                  <div>
                    <h1 className="text-2xl font-semibold text-neutral-950">Contact</h1>
                    <p className="mt-2 text-sm text-neutral-600">Guest checkout remains visible. Keep forms plain, readable, and low-friction.</p>
                  </div>
                  <Field label="Email" type="email" />
                  <Field label="Phone" type="tel" />
                  <div className="grid gap-5 md:grid-cols-2">
                    <Field label="Full name" />
                    <Field label="City" />
                  </div>
                  <Field label="Address" />
                  <Field label="Area / District" />
                  <div className="space-y-3 text-sm text-neutral-700">
                    <label className="flex items-center gap-3"><input type="checkbox" defaultChecked /> Guest checkout</label>
                    <label className="flex items-center gap-3"><input type="checkbox" /> Newsletter opt-in</label>
                  </div>
                  <button type="button" onClick={() => setStep(1)} className="rounded-full bg-neutral-950 px-5 py-3 text-sm font-medium text-white">Continue to Shipping</button>
                </div>
              ) : null}

              {step === 1 ? (
                <div className="space-y-5">
                  <div>
                    <h1 className="text-2xl font-semibold text-neutral-950">Shipping</h1>
                    <p className="mt-2 text-sm text-neutral-600">Price and delivery window must be visible before final payment.</p>
                  </div>
                  <div className="rounded-2xl bg-stone-50 p-4 text-sm text-neutral-700">Shipping to Cairo, Nasr City</div>
                  <label className="block rounded-2xl border border-neutral-900 p-4">
                    <div className="flex items-start gap-3">
                      <input type="radio" name="shipping" defaultChecked onChange={() => setShippingCost(60)} />
                      <div>
                        <p className="font-medium text-neutral-950">Standard — {money(60)}</p>
                        <p className="mt-1 text-sm text-neutral-600">2–4 business days · Cairo coverage</p>
                      </div>
                    </div>
                  </label>
                  <label className="block rounded-2xl border border-neutral-300 p-4">
                    <div className="flex items-start gap-3">
                      <input type="radio" name="shipping" onChange={() => setShippingCost(120)} />
                      <div>
                        <p className="font-medium text-neutral-950">Express — {money(120)}</p>
                        <p className="mt-1 text-sm text-neutral-600">1–2 business days · Cairo and selected areas</p>
                      </div>
                    </div>
                  </label>
                  <div className="flex flex-wrap gap-3">
                    <button type="button" onClick={() => setStep(2)} className="rounded-full bg-neutral-950 px-5 py-3 text-sm font-medium text-white">Continue to Payment</button>
                    <button type="button" onClick={() => setStep(0)} className="rounded-full border border-neutral-300 px-5 py-3 text-sm font-medium text-neutral-900">Back</button>
                  </div>
                </div>
              ) : null}

              {step === 2 ? (
                <div className="space-y-5">
                  <div>
                    <h1 className="text-2xl font-semibold text-neutral-950">Payment</h1>
                    <p className="mt-2 text-sm text-neutral-600">Trust elements stay close to the payment choice, not buried below the fold.</p>
                  </div>
                  <label className="block rounded-2xl border border-neutral-900 p-4">
                    <div className="flex items-start gap-3">
                      <input type="radio" name="payment" defaultChecked />
                      <div>
                        <p className="font-medium text-neutral-950">Cash on delivery</p>
                        <p className="mt-1 text-sm text-neutral-600">Pay when your order arrives. WhatsApp confirmation follows the order.</p>
                      </div>
                    </div>
                  </label>
                  <label className="block rounded-2xl border border-neutral-300 p-4">
                    <div className="flex items-start gap-3">
                      <input type="radio" name="payment" />
                      <div>
                        <p className="font-medium text-neutral-950">Card payment</p>
                        <p className="mt-1 text-sm text-neutral-600">Show payment logos here + secure payment note.</p>
                      </div>
                    </div>
                  </label>
                  <div className="rounded-2xl bg-stone-50 p-4 text-sm leading-7 text-neutral-700">
                    <p>🔒 Your data is safe</p>
                    <p>COD explained clearly</p>
                    <p><Link to="/returns" className="underline">Exchange policy</Link> remains visible</p>
                    <p>WhatsApp support entry should stay available</p>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <Link to="/checkout/success" className="rounded-full bg-neutral-950 px-5 py-3 text-sm font-medium text-white">Place Order — {money(total)}</Link>
                    <button type="button" onClick={() => setStep(1)} className="rounded-full border border-neutral-300 px-5 py-3 text-sm font-medium text-neutral-900">Back</button>
                  </div>
                </div>
              ) : null}
            </div>

            <aside className="rounded-[2rem] border border-neutral-200 bg-white p-6 shadow-sm xl:sticky xl:top-20">
              <h2 className="text-lg font-semibold text-neutral-950">Order summary</h2>
              <div className="mt-4 space-y-4">
                {cartItems.map((item) => (
                  <div key={`${item.slug}-${item.size}`} className="flex gap-3">
                    <img src={item.image} alt={item.name} className="h-16 w-16 rounded-2xl object-cover" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-neutral-950">{item.name}</p>
                      <p className="text-sm text-neutral-600">Size {item.size} · Qty {item.qty}</p>
                    </div>
                    <p className="text-sm text-neutral-950">{money(item.price)}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4 divide-y divide-neutral-200">
                <SummaryRow label="Subtotal" value={money(subtotal)} />
                <SummaryRow label="Shipping" value={money(shippingCost)} />
                <SummaryRow label="Total" value={money(total)} strong />
              </div>
            </aside>
          </div>
        </Container>
      </section>
    </PageShell>
  );
}

function Field({ label, type = 'text' }: { label: string; type?: string }) {
  return (
    <label className="block space-y-2 text-sm text-neutral-700">
      <span>{label}</span>
      <input type={type} className="w-full rounded-2xl border border-neutral-300 px-4 py-3 text-sm text-neutral-900 outline-none ring-0 placeholder:text-neutral-400 focus:border-neutral-900" />
    </label>
  );
}
