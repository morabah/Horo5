import { Link } from 'react-router-dom';
import type { ReactNode } from 'react';
import type { Artist, Product, Vibe } from './wireframe-data';
import { money } from './wireframe-data';

export function PageShell({ children }: { children: ReactNode }) {
  return <div className="min-h-screen bg-stone-50 text-neutral-900">{children}</div>;
}

export function Container({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 ${className}`.trim()}>{children}</div>;
}

export function TopNav() {
  return (
    <div className="border-b border-neutral-200 bg-white/95 backdrop-blur">
      <Container className="flex h-16 items-center justify-between gap-4">
        <Link to="/" className="text-lg font-semibold tracking-[0.25em] text-neutral-950">HORO</Link>
        <div className="hidden items-center gap-6 text-sm text-neutral-700 md:flex">
          <Link to="/vibes" className="hover:text-neutral-950">Shop by Vibe</Link>
          <Link to="/vibes/fictious" className="hover:text-neutral-950">New Drop</Link>
          <Link to="/artists" className="hover:text-neutral-950">Artists</Link>
          <Link to="/search?q=light" className="hover:text-neutral-950">Search</Link>
          <Link to="/cart" className="hover:text-neutral-950">Cart</Link>
        </div>
      </Container>
    </div>
  );
}

export function SectionTitle({ eyebrow, title, body }: { eyebrow?: string; title: string; body?: string }) {
  return (
    <div className="max-w-2xl">
      {eyebrow ? <p className="mb-3 text-xs font-medium uppercase tracking-[0.24em] text-amber-700">{eyebrow}</p> : null}
      <h2 className="text-2xl font-semibold tracking-tight text-neutral-950 sm:text-3xl">{title}</h2>
      {body ? <p className="mt-3 text-sm leading-6 text-neutral-600 sm:text-base">{body}</p> : null}
    </div>
  );
}

export function ProofPill({ children }: { children: ReactNode }) {
  return <span className="rounded-full border border-neutral-200 bg-white px-3 py-2 text-xs font-medium text-neutral-700">{children}</span>;
}

export function VibeCard({ vibe }: { vibe: Vibe }) {
  return (
    <Link to={`/vibes/${vibe.slug}`} className="group overflow-hidden rounded-3xl border border-neutral-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-md">
      <div className="aspect-[4/5] bg-gradient-to-br from-neutral-900 via-neutral-700 to-neutral-500" />
      <div className="space-y-3 p-5">
        <div className="flex items-start justify-between gap-4">
          <h3 className="text-lg font-semibold text-neutral-950">{vibe.name}</h3>
          <span className="text-xs text-neutral-500">{vibe.count} designs</span>
        </div>
        <p className="text-sm leading-6 text-neutral-600">{vibe.tagline}</p>
        <span className="inline-flex items-center text-sm font-medium text-neutral-950">Explore <span className="ml-1 transition group-hover:translate-x-1">→</span></span>
      </div>
    </Link>
  );
}

export function ProductCard({ product, showGiftBadge = false }: { product: Product; showGiftBadge?: boolean }) {
  return (
    <Link to={`/products/${product.slug}`} className="group overflow-hidden rounded-3xl border border-neutral-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-md">
      <div className="relative aspect-[4/5] overflow-hidden bg-neutral-200">
        <img src={product.image} alt={product.name} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
        <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-[11px] font-medium text-neutral-700">{product.vibe}</span>
        {showGiftBadge && product.giftReady ? <span className="absolute right-3 top-3 rounded-full bg-amber-100 px-2.5 py-1 text-[11px] font-medium text-amber-900">Gift-ready</span> : null}
      </div>
      <div className="space-y-2 p-4">
        <p className="text-xs uppercase tracking-[0.18em] text-neutral-500">Illustrated by {product.artist}</p>
        <h3 className="text-base font-semibold text-neutral-950">{product.name}</h3>
        <div className="flex items-center justify-between gap-4 text-sm">
          <span className="font-medium text-neutral-950">{money(product.price)}</span>
          <span className="text-neutral-600">View details</span>
        </div>
      </div>
    </Link>
  );
}

export function ArtistCard({ artist }: { artist: Artist }) {
  return (
    <Link to={`/artists/${artist.slug}`} className="rounded-3xl border border-neutral-200 bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-md">
      <div className="mb-4 flex items-center gap-4">
        <div className="h-16 w-16 rounded-full bg-gradient-to-br from-neutral-200 to-neutral-300" />
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-neutral-500">Illustrated by</p>
          <h3 className="text-lg font-semibold text-neutral-950">{artist.name}</h3>
        </div>
      </div>
      <p className="text-sm leading-6 text-neutral-600">{artist.style}</p>
      <div className="mt-4 grid grid-cols-3 gap-2">
        <div className="aspect-square rounded-2xl bg-neutral-200" />
        <div className="aspect-square rounded-2xl bg-neutral-200" />
        <div className="aspect-square rounded-2xl bg-neutral-200" />
      </div>
      <div className="mt-4 flex items-center justify-between text-sm">
        <span className="text-neutral-500">{artist.count} designs</span>
        <span className="font-medium text-neutral-950">View portfolio →</span>
      </div>
    </Link>
  );
}

export function TrustList({ items }: { items: string[] }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {items.map((item) => (
        <div key={item} className="rounded-2xl border border-neutral-200 bg-white px-4 py-3 text-sm text-neutral-700">{item}</div>
      ))}
    </div>
  );
}

export function SummaryRow({ label, value, strong = false }: { label: string; value: ReactNode; strong?: boolean }) {
  return (
    <div className={`flex items-center justify-between gap-6 py-2 text-sm ${strong ? 'font-semibold text-neutral-950' : 'text-neutral-700'}`}>
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}

export function FooterCta({ title, primaryLabel, primaryTo, secondaryLabel, secondaryTo }: { title: string; primaryLabel: string; primaryTo: string; secondaryLabel?: string; secondaryTo?: string }) {
  return (
    <section className="border-t border-neutral-200 bg-white py-16">
      <Container className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.24em] text-amber-700">Next step</p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight text-neutral-950">{title}</h2>
        </div>
        <div className="flex flex-wrap gap-3">
          <Link to={primaryTo} className="rounded-full bg-neutral-950 px-5 py-3 text-sm font-medium text-white">{primaryLabel}</Link>
          {secondaryLabel && secondaryTo ? <Link to={secondaryTo} className="rounded-full border border-neutral-300 px-5 py-3 text-sm font-medium text-neutral-800">{secondaryLabel}</Link> : null}
        </div>
      </Container>
    </section>
  );
}
